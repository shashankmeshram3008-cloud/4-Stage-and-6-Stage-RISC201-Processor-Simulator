# Risc201 Processor Design — 4-stage & 6-stage (Combined Package)

This package contains **two** Risc201 processor simulators. Both execute a
**true overlapping pipeline** controlled end-to-end by the same **vertical
microcode** design (32-bit µword, one action per µop) and the same
**bitwise ALU** (Carry-Lookahead Adder + Booth multiplier + Goldschmidt
divider).

| Directory          | Pipeline stages             | Execution        | Taken-branch penalty |
|--------------------|-----------------------------|------------------|----------------------|
| `risc201-4stage/`  | IF / ID / EX / WB           | overlapping, CPI 1.25–1.75 | 2 bubbles |
| `risc201-6stage/`  | IF / ID / OF / EX / MA / WB | overlapping, CPI 1.4–1.8  | 3 bubbles |

Both projects share the same ISA, ALU, register file, memory, stack
subsystem, assembler, disassembler, and CLI debugger — only the pipeline
depth (and therefore the µop→stage assignment) differs.

## Execution model

**Both simulators execute instructions in an overlapping pipeline.**
Every clock cycle, ALL stages interpret their microcode in
parallel, and several instructions are in flight simultaneously.

The mechanism that makes this work while staying **fully vertical
controlled**:

- Each in-flight instruction **carries its own µPC** (micro program
  counter) inside the pipeline registers.
- Each stage is a vertical µop interpreter: it walks the µword at the
  packet's µPC, **executes only the µops statically assigned to it**
  (e.g. `ALU_OP` belongs to EX, `MEM_READ` to MA/EX, `REG_WRITE` to WB),
  skips µops already consumed by earlier stages, and stops at µops owned
  by later stages. `JMP_MICRO → FETCH` is the retirement marker, consumed
  by WB.
- The µword layout is identical in both CPUs (`rom[0]=FETCH_IR`,
  `rom[2]=DECODE`, opcode routines at `16 + opcode*4`, terminated by a
  jump to FETCH). No hardwired control logic exists anywhere — every
  register write, ALU operation, memory access, PC load, and flag commit
  happens because a vertical µword said so.
- In steady state **one instruction retires per cycle**. CPI > 1 comes
  only from branch squashes, the 6-stage's 1-cycle load-use interlock,
  and pipeline fill/drain.

## Hazard handling (both CPUs)

| Hazard | 4-stage | 6-stage |
|--------|---------|---------|
| RAW via bypass | fully bypassed into ID — **0 stalls** (even load-use: the fused ID stage reads in the same cycle EX produces load data) | fully bypassed into OF for ALU producers; **1 bubble** when a `ld` feeds the very next instruction (classic load-use interlock) |
| Flags (`cmp` → `beq`/`bgt`) | `SET_FLAGS` commits in EX; branch reads in EX — **0 stalls** | same — **0 stalls** |
| `ra` (`call` → `ret`) | `LINK_RA` commits in EX — **0 stalls** | same |
| Taken branch | redirect in EX, squash IF/ID + ID/EX = **2 bubbles** | redirect in EX, squash IF/ID + ID/OF + OF/EX = **3 bubbles** |
| Not-taken branch | **0 bubbles** | **0 bubbles** |

Redirecting µops execute in EX because that is the last point at which no
younger instruction has committed architectural state — the squash is
always precise. Exceptions (DivByZero in EX, StackOverflow in WB) squash
the faulting packet and everything younger.

## Quick start

```bash
# Build both simulators
make -C risc201-4stage
make -C risc201-6stage

# Run a program
./risc201-4stage/risc201-4stage risc201-4stage/programs/factorial.s
./risc201-6stage/risc201-6stage  risc201-6stage/programs/factorial.s

# Per-cycle reservation-table trace (shows the overlap directly)
./risc201-6stage/risc201-6stage risc201-6stage/programs/expr.s --trace

# Interactive debugger ('m' steps one clock cycle, 'p'/'u' show per-stage µPCs)
./risc201-4stage/risc201-4stage risc201-4stage/programs/factorial.s --debug
./risc201-6stage/risc201-6stage  risc201-6stage/programs/factorial.s  --debug
```

## Benchmark: 4-stage vs 6-stage

Same programs, same ROM, same ISA, and identical retired instruction
streams. `time = cycles × clock_period` (4-stage 1.0 ns, 6-stage 0.77 ns),
so the two CPUs are compared on both cycles and wall-clock time.

| Program             | 4st cyc | 4st CPI | 6st cyc | 6st CPI | cyc ratio 6/4 | time ratio 6/4 |
|---------------------|---------|---------|---------|---------|---------------|----------------|
| arithmetic          | 15      | 1.25    | 17      | 1.42    | 1.13          | 0.87           |
| bubble_sort         | 629     | 1.35    | 746     | 1.60    | 1.19          | 0.91           |
| call_test           | 13      | 2.17    | 17      | 2.83    | 1.31          | 1.01           |
| expr                | 7       | 1.75    | 9       | 2.25    | 1.29          | 0.99           |
| factorial           | 34      | 1.48    | 40      | 1.74    | 1.18          | 0.91           |
| factorial_iterative | 44      | 1.42    | 51      | 1.65    | 1.16          | 0.89           |
| factorial_recursive | 132     | 1.33    | 149     | 1.51    | 1.13          | 0.87           |
| fibonacci           | 99      | 1.30    | 111     | 1.46    | 1.12          | 0.86           |
| gcd                 | 26      | 1.53    | 31      | 1.82    | 1.19          | 0.92           |
| mem_branch          | 78      | 1.32    | 96      | 1.63    | 1.23          | 0.95           |
| prime               | 221     | 1.33    | 249     | 1.50    | 1.13          | 0.87           |
| stack_call          | 132     | 1.33    | 149     | 1.51    | 1.13          | 0.87           |
| stack_overflow      | 36865   | 1.29    | 40963   | 1.43    | 1.11          | 0.86           |
| sum_1_to_100        | 709     | 1.40    | 811     | 1.60    | 1.14          | 0.88           |
| sum_array           | 51      | 1.42    | 64      | 1.78    | 1.25          | 0.97           |

**Observations:**

- Both CPUs finish with **identical register files** on all 15 programs
  (verified by script, including the StackOverflow exception test) and
  retire identical instruction counts, so the comparison measures overlap
  quality and clocking only.
- The 4-stage always needs fewer cycles (CPI 1.25–2.17 vs 1.42–2.83):
  shallower fill (4 vs 6 cycles), 2-bubble squash vs 3, and no load-use
  interlock.
- The 6-stage's 23% shorter clock period wins in wall-clock time on
  14 of 15 programs (up to 14% sooner); the two are even on the tiny
  `call_test` (1.01), where the 4-stage's shorter fill dominates.

## Timing model

Synthetic timing model: `time = cycles × clock_period`.

| CPU     | Critical path                          | Clock period |
|---------|----------------------------------------|--------------|
| 4-stage | `t_EX = t_ALU + t_memory ≈ 1050 ps`    | **1.00 ns/cycle** |
| 6-stage | `max(t_EX ≈ 700 ps, t_MA ≈ 350 ps)`    | **0.77 ns/cycle**  |

## Per-stage µop assignment (the control plan)

| µop (32-bit vertical µword) | 4-stage | 6-stage |
|-----------------------------|---------|---------|
| `FETCH_IR`                  | IF      | IF      |
| `DECODE`                    | ID      | ID      |
| `OF_READ`                   | ID      | OF      |
| `ALU_OP`, `SET_FLAGS`       | EX      | EX      |
| `COMPUTE_TARGET`, `COND_BRANCH`, `PC_LOAD_TARGET`, `LINK_RA` | EX | EX |
| `MEM_READ`, `MEM_WRITE`     | EX      | MA      |
| `REG_WRITE`                 | WB      | WB      |
| `JMP_MICRO → FETCH`         | WB (retire) | WB (retire) |

Both CPUs share the same routine layout: `rom[0]=FETCH_IR`,
`rom[1]=JMP→DECODE`, `rom[2]=DECODE`, opcode routine at `16 + opcode*4`
terminated by `JMP→FETCH`. The µop set is unified across the two CPUs,
so the ROM builder is structurally identical in both projects.

## What's shared between the two projects

- The same Risc201 ISA (21 instructions, 3 encoding formats, 16 registers).
- The same bitwise ALU: **Carry-Lookahead Adder** (2-level group
  lookahead), **Booth radix-2 multiplier** (32×32 → 64-bit),
  **Goldschmidt division** (Q1.31 fixed-point, internal multiplies via
  Booth).
- The same register file (16 × 32-bit), byte-addressable little-endian
  memory, full-descending stack with boundary safety + ASCII visualizer.
- The same two-pass assembler, disassembler, and CLI debugger.
- The same runtime exception framework (division-by-zero, stack
  overflow/underflow, stack misalignment — all carrying macro PC + µPC).

## Package layout

```
risc201-combined/
├── README.md                              (this file)
├── risc201-4stage/                     4-stage operational pipeline (IF/ID/EX/WB)
│   ├── include/risc201/
│   │   ├── isa.hpp                        Risc201 ISA (shared)
│   │   ├── alu.hpp                        CLA + Booth + Goldschmidt (shared)
│   │   ├── core.hpp                       regfile + memory + stack (shared)
│   │   ├── cpu4.hpp                       CPU4V — packet, stage µop map, bypass network
│   │   ├── assembler.hpp                  shared two-pass assembler
│   │   └── debugger.hpp                   pipeline-aware trace logger + REPL
│   ├── src/{cpu4,main}.cpp
│   ├── programs/*.s                       15 test programs (identical in both)
│   ├── Makefile
│   └── README.md
└── risc201-6stage/                     6-stage operational pipeline (IF/ID/OF/EX/MA/WB)
    ├── include/risc201/  (same set, cpu6.hpp / cpu6.cpp)
    ├── src/{cpu6,main}.cpp
    ├── programs/*.s
    ├── Makefile
    └── README.md
```

## CLI usage (both simulators)

```bash
./risc201-4stage/risc201-4stage risc201-4stage/programs/factorial.s --listing
./risc201-6stage/risc201-6stage  risc201-6stage/programs/factorial.s  --disasm
./risc201-4stage/risc201-4stage risc201-4stage/programs/factorial.s           # run
./risc201-6stage/risc201-6stage  risc201-6stage/programs/factorial.s  --trace # per-cycle
./risc201-4stage/risc201-4stage risc201-4stage/programs/factorial.s --debug
```

### Debugger commands (both simulators)

| Command | Action |
|---------|--------|
| `s`     | run until the next instruction retires (macro step) |
| `m`     | step **one clock cycle** — every stage interprets its µops |
| `r`     | register file + flags |
| `p`     | pipeline snapshot (packet + µPC per stage, MAR/MDR, stats) |
| `u`     | per-stage microcode sequencer state (all µPCs + µwords) |
| `d <addr>` | disassemble 16 instructions |
| `mem <addr>` | dump 16 memory words |
| `st` / `cs` | stack visualizer / stack safety |
| `c <n>` | run up to n macro steps |
| `q`     | quit |

## Test programs (15 total, identical in both projects)

| Program                | Computes                         | Result register | Expected |
|------------------------|----------------------------------|-----------------|----------|
| `arithmetic.s`         | All ALU ops                      | —               | —        |
| `bubble_sort.s`        | Sort 8 integers in place         | arr[]           | sorted   |
| `call_test.s`          | call/ret add 3+4                 | r2              | 7        |
| `expr.s`               | 31*29-50                         | r4              | 849      |
| `factorial.s`          | 6! iterative                     | r1              | 720      |
| `factorial_iterative.s`| 5! iterative                     | r0              | 120      |
| `factorial_recursive.s`| 5! recursive (stack)             | r0              | 120      |
| `fibonacci.s`          | fib(10)                          | r1              | 55       |
| `gcd.s`                | gcd(48,36)                       | r2              | 12       |
| `mem_branch.s`         | Array sum with ld + loop         | r3              | 36       |
| `prime.s`              | Is 29 prime?                     | r0              | 1        |
| `stack_call.s`         | Recursive factorial via stack    | r0              | 120      |
| `stack_overflow.s`     | Infinite recursion → exception   | —               | `StackOverflow` @ pc=0x18 (SP=0x7ffc < LIMIT=0x8000) |
| `sum_1_to_100.s`       | 1+2+...+100                      | r0              | 5050     |
| `sum_array.s`          | Sum of array via ld              | r0              | 75       |

All 15 produce results identical to the sequential baseline on both CPUs.

## Stack overflow detection

Stack semantics: a full-descending stack bounded by
`STACK_BASE = 0xFFFC` and `STACK_LIMIT = 0x8000`. Any instruction whose
destination register is `sp` is checked in the WB-stage `REG_WRITE`
µaction; crossing the floor raises `StackOverflow`, and every younger
in-flight packet is squashed (precise squash — younger packets have not
reached MA/WB commit points when WB raises).

```
runtime exception: StackOverflow at pc=0x18 — SP=0x00007ffc crossed stack floor (LIMIT=0x00008000)
```

## Risc201 ISA quick reference

- **16 registers** `r0..r15` (32-bit). `r14 = sp`, `r15 = ra`.
  Internal **flags**: `E` (equal), `GT` (greater-than), written only by `cmp`.
- **32-bit fixed-width instructions**, 3 encoding formats:
  branch `op(5)|offset(27)`; register `op(5)|I=0|rd(4)|rs1(4)|rs2(4)`;
  immediate `op(5)|I=1|rd(4)|rs1(4)|imm(18 = mod(2)+const(16))`.
- **21 opcodes**: `add sub mul div mod cmp and or not mov lsl lsr asr nop
  ld st beq bgt b call ret`.
- **Immediate modifiers** (`u`/`h` suffix on ALU ops except shifts):
  default = sign-extend; `u` = zero-extend; `h` = upper 16 bits.

Verified against the book: `sub r1,r2,3` → `0x0C480003`,
`st r8,20[r2]` → `0x7E080014` (Section 3.3.14).
