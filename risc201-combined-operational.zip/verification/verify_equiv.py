#!/usr/bin/env python3
"""Verify semantic equivalence: pipelined simulators vs sequential baseline.

For every program, compare the full 16-register dump + flags of the new
pipelined build against the saved baseline (sequential) output.
"""
import re, subprocess, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)                       # .../risc201-combined
BASE = os.path.join(HERE, "baseline")
NEW6 = os.path.join(PKG, "risc201-6stage", "risc201-6stage")
NEW4 = os.path.join(PKG, "risc201-4stage", "risc201-4stage")
PROGS = os.path.join(PKG, "risc201-6stage", "programs")

def parse_regs(text):
    """Extract register values + flags from a regfile snapshot."""
    regs = {}
    for m in re.finditer(r'(r\d+|sp|ra)=0x([0-9a-f]{8})', text):
        regs[m.group(1)] = m.group(2)
    fl = re.search(r'flags: E=(\d) GT=(\d)', text)
    if fl:
        regs['E'] = fl.group(1); regs['GT'] = fl.group(2)
    return regs

def run(binary, prog):
    r = subprocess.run([binary, prog], capture_output=True, text=True, timeout=120)
    return r.stdout

def main():
    programs = sorted(f for f in os.listdir(PROGS) if f.endswith('.s'))
    all_ok = True
    print(f"{'program':<22} {'4-stage':<10} {'6-stage':<10}")
    for p in programs:
        name = p[:-2]
        base6 = parse_regs(open(f"{BASE}/{name}.6st.txt").read())
        base4 = parse_regs(open(f"{BASE}/{name}.4st.txt").read())
        new6  = parse_regs(run(NEW6, f"{PROGS}/{p}"))
        new4  = parse_regs(run(NEW4, f"{PROGS}/{p}")) if os.path.exists(NEW4) else {}
        ok6 = (new6 == base6)
        ok4 = (new4 == base4) if new4 else None
        # exception programs: baseline file may contain exception line; regs compare only
        s6 = "PASS" if ok6 else "FAIL"
        s4 = ("PASS" if ok4 else "FAIL") if new4 else "n/a"
        if not ok6 or (new4 and not ok4): all_ok = False
        print(f"{name:<22} {s4:<10} {s6:<10}")
        if not ok6:
            print("   6-stage diff:")
            for k in sorted(set(base6) | set(new6)):
                if base6.get(k) != new6.get(k):
                    print(f"     {k}: base={base6.get(k)} new={new6.get(k)}")
        if new4 and not ok4:
            print("   4-stage diff:")
            for k in sorted(set(base4) | set(new4)):
                if base4.get(k) != new4.get(k):
                    print(f"     {k}: base={base4.get(k)} new={new4.get(k)}")
    print("\nRESULT:", "ALL PASS - semantic equivalence verified" if all_ok else "FAILURES FOUND")
    sys.exit(0 if all_ok else 1)

main()
