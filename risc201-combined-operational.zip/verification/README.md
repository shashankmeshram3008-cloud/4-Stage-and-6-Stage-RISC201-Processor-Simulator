# Semantic-equivalence verification

`verify_equiv.py` proves that the operational pipelined CPUs are semantically
equivalent to a sequential reference execution of the same ISA and microcode:
for every one of the 15 test
programs it compares the complete final register file (16 registers + flags)
of both pipelined builds against the saved sequential-reference outputs in
`baseline/`.

Run from this directory:

    python3 verify_equiv.py

Expected result: 30/30 PASS (15 programs x 2 CPUs).

To regenerate the baseline outputs, run a sequential reference simulator
over `risc201-6stage/programs/*.s` and save the full outputs as
`baseline/<name>.6st.txt` / `<name>.4st.txt`.
