// risc201/assembler.hpp — Two-pass Risc201 assembler + disassembler.
//
// Translates Risc201 assembly (GNU-style syntax, as in the Sarangi book)
// into a vector of 32-bit machine words.  Produces a listing and a symbol table.
//
// Supported syntax:
//   - Labels:        .loop:   or   loop:     (a line may be just a label)
//   - Comments:      @ line comment   /* block */   // line comment
//   - Registers:     r0..r15, sp(=r14), ra(=r15)
//   - Immediates:    decimal (-5), hex (0xFF), binary (0b101)
//   - Modifiers:     suffix on ALU mnemonics (except shifts): addu, movh, subh
//   - 3-address ALU: add r1, r2, r3   |   add r1, r2, 10
//   - cmp/mov/not:   cmp r1, r2       |   mov r1, 3      |   not r1, r2
//   - load/store:    ld r1, 12[r2]    |   st r1, -4[sp]
//   - branches:      b .loop          |   beq .foo       |   bgt .bar
//   - call/ret:      call .func       |   ret
//   - nop
//   - Directives:    .word 1,2,3      (emit 32-bit data words)
//                    .word 0x10
//                    .start label     (set entry point)
//
// Branch offsets are PC-relative, measured in 4-byte words:
//     offset_words = (target_address - branch_address) / 4

#pragma once

#include "isa.hpp"
#include <string>
#include <vector>
#include <unordered_map>
#include <sstream>
#include <iomanip>
#include <cstdint>
#include <cctype>
#include <algorithm>

namespace risc201 {

struct AssembleResult {
    std::vector<uint32_t> words;
    std::unordered_map<std::string, uint32_t> symbols;
    std::vector<std::string> errors;
    std::vector<std::string> listing;
    bool ok = false;
    uint32_t entry = 0;
    uint32_t image_size = 0;
};

// ---- string utilities ----
inline std::string trim_str(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

inline std::string strip_comments(const std::string& line) {
    std::string out;
    out.reserve(line.size());
    bool inBlock = false;
    for (size_t i = 0; i < line.size(); ++i) {
        char c = line[i];
        if (inBlock) {
            if (c == '*' && i + 1 < line.size() && line[i+1] == '/') { inBlock = false; ++i; }
            continue;
        }
        if (c == '/' && i + 1 < line.size() && line[i+1] == '*') { inBlock = true; ++i; continue; }
        if (c == '@' || c == ';') break;
        if (c == '/' && i + 1 < line.size() && line[i+1] == '/') break;
        out.push_back(c);
    }
    return out;
}

inline std::vector<std::string> split_ws(const std::string& s) {
    std::vector<std::string> out;
    std::string cur;
    for (char c : s) {
        if (std::isspace((unsigned char)c)) { if (!cur.empty()) { out.push_back(cur); cur.clear(); } }
        else cur.push_back(c);
    }
    if (!cur.empty()) out.push_back(cur);
    return out;
}

inline bool parse_immediate(const std::string& s, int64_t& out, std::string& err) {
    std::string t = trim_str(s);
    if (t.empty()) { err = "empty immediate"; return false; }
    try {
        std::string num = t;
        int base = 10;
        if (num.size() > 2 && num[0] == '0' && (num[1] == 'x' || num[1] == 'X')) { base = 16; num = num.substr(2); }
        else if (num.size() > 2 && num[0] == '0' && (num[1] == 'b' || num[1] == 'B')) { base = 2; num = num.substr(2); }
        bool neg = false;
        if (!num.empty() && (num[0] == '+' || num[0] == '-')) { neg = (num[0] == '-'); num = num.substr(1); }
        size_t pos = 0;
        out = std::stoll(num, &pos, base);
        if (pos != num.size()) { err = "bad immediate: '" + s + "'"; return false; }
        if (neg) out = -out;
        return true;
    } catch (...) { err = "bad immediate: '" + s + "'"; return false; }
}

// Split operands on commas, keeping offset[reg] together.
inline std::vector<std::string> split_operands(const std::string& s) {
    std::vector<std::string> out;
    std::string cur;
    int depth = 0;
    for (char c : s) {
        if (c == '[') { depth++; cur.push_back(c); }
        else if (c == ']') { depth--; cur.push_back(c); }
        else if (c == ',' && depth == 0) { out.push_back(trim_str(cur)); cur.clear(); }
        else cur.push_back(c);
    }
    if (!trim_str(cur).empty() || !out.empty()) out.push_back(trim_str(cur));
    return out;
}

inline bool parse_mem_operand(const std::string& s, std::string& offStr, std::string& regStr, std::string& err) {
    auto lb = s.find('[');
    auto rb = s.find(']');
    if (lb == std::string::npos || rb == std::string::npos || rb < lb) {
        err = "expected offset[reg], got: '" + s + "'"; return false;
    }
    offStr = trim_str(s.substr(0, lb));
    regStr = trim_str(s.substr(lb + 1, rb - lb - 1));
    if (offStr.empty()) offStr = "0";
    return true;
}

// Extract a leading "label:" from a line; returns the rest.
inline void extract_label(std::string& line, std::string& label) {
    label.clear();
    std::string t = trim_str(line);
    int depth = 0;
    for (size_t i = 0; i < t.size(); ++i) {
        char c = t[i];
        if (c == '[') depth++;
        else if (c == ']') depth--;
        else if (c == ':' && depth == 0) {
            label = t.substr(0, i);
            line = trim_str(t.substr(i + 1));
            return;
        }
    }
    line = t;
}

inline bool is_directive(const std::string& tok) {
    return tok == ".word" || tok == ".org" || tok == ".start" || tok == ".end";
}

// ---- Main assembler ----
inline AssembleResult assemble(const std::string& source) {
    AssembleResult res;

    // Split into raw source lines
    std::vector<std::string> rawLines;
    {
        std::string cur;
        for (char c : source) {
            if (c == '\n') { rawLines.push_back(cur); cur.clear(); }
            else cur.push_back(c);
        }
        if (!cur.empty()) rawLines.push_back(cur);
    }

    struct ParsedLine {
        int sourceLine = 0;
        std::string label;
        std::string mnemonic;
        bool isDirective = false;
        std::string directive;
        std::vector<std::string> operands;
        std::string raw;
        bool blank = false;
    };

    // Pass 1: parse + collect labels
    std::vector<ParsedLine> parsed;
    parsed.reserve(rawLines.size());
    uint32_t addr = 0;

    for (int ln = 0; ln < (int)rawLines.size(); ++ln) {
        std::string line = strip_comments(rawLines[ln]);
        std::string label;
        extract_label(line, label);
        line = trim_str(line);

        ParsedLine pl;
        pl.sourceLine = ln + 1;
        pl.raw = trim_str(rawLines[ln]);

        if (!label.empty()) {
            pl.label = label;
            if (res.symbols.count(label)) {
                res.errors.push_back("line " + std::to_string(ln+1) + ": duplicate label: '" + label + "'");
                res.ok = false;
                return res;
            }
            res.symbols[label] = addr;
        }

        if (line.empty()) { pl.blank = true; parsed.push_back(pl); continue; }

        std::istringstream iss(line);
        std::string mnem; iss >> mnem;
        std::string rest; std::getline(iss, rest);
        rest = trim_str(rest);

        if (is_directive(mnem)) {
            pl.isDirective = true;
            pl.directive = mnem;
            pl.operands = split_operands(rest);
            if (mnem == ".word") addr += 4 * (uint32_t)pl.operands.size();
            else if (mnem == ".org") {
                int64_t v; std::string e;
                if (!parse_immediate(pl.operands.empty() ? "0" : pl.operands[0], v, e)) {
                    res.errors.push_back("line " + std::to_string(ln+1) + ": bad .org: " + e);
                    res.ok = false; return res;
                }
                addr = (uint32_t)v;
            }
        } else {
            pl.mnemonic = mnem;
            pl.operands = split_operands(rest);
            addr += 4;
        }
        parsed.push_back(pl);
    }

    res.image_size = addr;

    // Pass 2: encode
    addr = 0;
    for (auto& pl : parsed) {
        if (pl.blank) {
            res.listing.push_back(pl.raw);
            continue;
        }

        if (pl.isDirective) {
            if (pl.directive == ".word") {
                for (auto& op : pl.operands) {
                    int64_t v; std::string e;
                    if (!parse_immediate(op, v, e)) {
                        res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": bad .word operand '" + op + "': " + e);
                        res.ok = false; return res;
                    }
                    uint32_t w = (uint32_t)v;
                    char buf[128];
                    std::snprintf(buf, sizeof(buf), "0x%06x 0x%08x  %s", addr, w, pl.raw.c_str());
                    res.listing.push_back(buf);
                    res.words.push_back(w);
                    addr += 4;
                }
            } else if (pl.directive == ".start") {
                if (!pl.operands.empty()) {
                    auto it = res.symbols.find(pl.operands[0]);
                    if (it != res.symbols.end()) res.entry = it->second;
                    else { int64_t v; std::string e;
                        if (parse_immediate(pl.operands[0], v, e)) res.entry = (uint32_t)v; }
                }
            }
            continue;
        }

        // Encode an instruction
        Decoded d;
        std::string base; Modifier mod;
        if (!parse_mnemonic(pl.mnemonic, base, mod)) {
            res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": unknown mnemonic: '" + pl.mnemonic + "'");
            res.ok = false; return res;
        }
        auto* info = info_by_mnemonic(base);
        d.op = info->op;
        d.mod = mod;

        auto resolveRegOrImm = [&](const std::string& op, bool& isImm, int32_t& immVal, int& regNum) -> bool {
            std::string e;
            int r = parse_register(op, &e);
            if (r >= 0) { isImm = false; regNum = r; return true; }
            int64_t v;
            if (parse_immediate(op, v, e)) { isImm = true; immVal = (int32_t)v; return true; }
            auto it = res.symbols.find(op);
            if (it != res.symbols.end()) { isImm = true; immVal = (int32_t)it->second; return true; }
            res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": bad operand: '" + op + "'");
            return false;
        };

        bool ok = true;
        switch (d.op) {
            case OP_NOP: case OP_RET:
                d.format = Fmt::BRANCH;
                break;
            case OP_B: case OP_BEQ: case OP_BGT: case OP_CALL: {
                d.format = Fmt::BRANCH;
                if (pl.operands.size() != 1) {
                    res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": branch expects 1 label operand");
                    ok = false; break;
                }
                std::string tgt = trim_str(pl.operands[0]);
                uint32_t targetAddr;
                auto it = res.symbols.find(tgt);
                if (it != res.symbols.end()) targetAddr = it->second;
                else {
                    int64_t v; std::string e;
                    if (!parse_immediate(tgt, v, e)) {
                        res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": unknown label/operand: '" + tgt + "'");
                        ok = false; break;
                    }
                    targetAddr = (uint32_t)v;
                }
                int32_t off = (int32_t)((int64_t)targetAddr - (int64_t)addr) / 4;
                if (off < -(1 << 26) || off >= (1 << 26)) {
                    res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": branch offset out of range");
                    ok = false; break;
                }
                d.offset = off;
                break;
            }
            case OP_MOV: case OP_NOT: {
                if (pl.operands.size() != 2) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": expected 2 operands"); ok = false; break; }
                std::string e;
                int rd = parse_register(pl.operands[0], &e);
                if (rd < 0) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": " + e); ok = false; break; }
                d.rd = rd;
                bool isImm; int32_t imm; int reg;
                if (!resolveRegOrImm(pl.operands[1], isImm, imm, reg)) { ok = false; break; }
                if (isImm) {
                    d.is_immediate = true; d.format = Fmt::IMMEDIATE; d.imm = imm;
                    if (mod == Modifier::DEFAULT && (imm < -32768 || imm > 32767)) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": immediate out of range (use u/h)"); ok = false; break; }
                } else { d.is_immediate = false; d.format = Fmt::REGISTER; d.rs2 = reg; }
                break;
            }
            case OP_CMP: {
                if (pl.operands.size() != 2) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": expected 2 operands"); ok = false; break; }
                std::string e;
                int rs1 = parse_register(pl.operands[0], &e);
                if (rs1 < 0) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": " + e); ok = false; break; }
                d.rs1 = rs1;
                bool isImm; int32_t imm; int reg;
                if (!resolveRegOrImm(pl.operands[1], isImm, imm, reg)) { ok = false; break; }
                if (isImm) {
                    d.is_immediate = true; d.format = Fmt::IMMEDIATE; d.imm = imm;
                    if (mod == Modifier::DEFAULT && (imm < -32768 || imm > 32767)) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": immediate out of range (use u/h)"); ok = false; break; }
                } else { d.is_immediate = false; d.format = Fmt::REGISTER; d.rs2 = reg; }
                break;
            }
            case OP_LD: case OP_ST: {
                if (pl.operands.size() != 2) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": expected 2 operands"); ok = false; break; }
                std::string e;
                int rd = parse_register(pl.operands[0], &e);
                if (rd < 0) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": " + e); ok = false; break; }
                d.rd = rd;
                std::string offStr, regStr;
                if (!parse_mem_operand(pl.operands[1], offStr, regStr, e)) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": " + e); ok = false; break; }
                int rs1 = parse_register(regStr, &e);
                if (rs1 < 0) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": " + e); ok = false; break; }
                d.rs1 = rs1;
                int64_t off;
                auto it = res.symbols.find(offStr);
                if (it != res.symbols.end()) off = it->second;
                else if (!parse_immediate(offStr, off, e)) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": bad offset: " + e); ok = false; break; }
                d.is_immediate = true; d.format = Fmt::IMMEDIATE; d.imm = (int32_t)off;
                if (off < -32768 || off > 32767) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": memory offset out of 16-bit range"); ok = false; break; }
                break;
            }
            default: {
                if (pl.operands.size() != 3) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": expected 3 operands"); ok = false; break; }
                std::string e;
                int rd = parse_register(pl.operands[0], &e);
                if (rd < 0) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": " + e); ok = false; break; }
                int rs1 = parse_register(pl.operands[1], &e);
                if (rs1 < 0) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": " + e); ok = false; break; }
                d.rd = rd; d.rs1 = rs1;
                bool isImm; int32_t imm; int reg;
                if (!resolveRegOrImm(pl.operands[2], isImm, imm, reg)) { ok = false; break; }
                if (isImm) {
                    d.is_immediate = true; d.format = Fmt::IMMEDIATE; d.imm = imm;
                    if (mod == Modifier::U && (uint32_t)imm > 0xFFFF) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": immediate out of range for 'u'"); ok = false; break; }
                    if (mod == Modifier::DEFAULT && (imm < -32768 || imm > 32767)) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": immediate out of range (use u/h)"); ok = false; break; }
                    if (mod == Modifier::H && (uint32_t)imm > 0xFFFF) { res.errors.push_back("line " + std::to_string(pl.sourceLine) + ": immediate out of range for 'h'"); ok = false; break; }
                } else { d.is_immediate = false; d.format = Fmt::REGISTER; d.rs2 = reg; }
                break;
            }
        }
        if (!ok) { res.ok = false; return res; }

        uint32_t word = encode(d);
        char buf[256];
        std::snprintf(buf, sizeof(buf), "0x%06x 0x%08x  %s    ; %s", addr, word, pl.raw.c_str(), disasm_text(d, addr).c_str());
        res.listing.push_back(buf);
        res.words.push_back(word);
        addr += 4;
    }

    res.ok = true;
    return res;
}

// ---- Disassembler ----
inline std::string disassemble_word(uint32_t word, uint32_t pc = 0) {
    Decoded d = decode(word);
    return disasm_text(d, pc);
}

inline std::string disassemble_program(const std::vector<uint32_t>& words, uint32_t base = 0) {
    std::ostringstream os;
    os << "Addr     Word       Assembly\n";
    os << "-------- ---------- -----------------------------------------------\n";
    for (size_t i = 0; i < words.size(); ++i) {
        uint32_t addr = base + (uint32_t)i * 4;
        char buf[128];
        std::snprintf(buf, sizeof(buf), "0x%06x 0x%08x  ", addr, words[i]);
        os << buf << disasm_text(decode(words[i]), addr) << "\n";
    }
    return os.str();
}

// Parse a hex stream into 32-bit words.
inline bool parse_hex_stream(const std::string& s, std::vector<uint32_t>& out, std::string& err) {
    size_t pos = 0;
    auto nextTok = [&]() -> std::string {
        while (pos < s.size() && (std::isspace((unsigned char)s[pos]) || s[pos] == ',' || s[pos] == ';')) pos++;
        if (pos >= s.size()) return "";
        if (s[pos] == '@' || (s[pos] == '/' && pos + 1 < s.size() && s[pos+1] == '/')) {
            while (pos < s.size() && s[pos] != '\n') pos++;
            // re-call via lambda recursion: just loop
            while (pos < s.size() && (std::isspace((unsigned char)s[pos]) || s[pos] == ',' || s[pos] == ';')) pos++;
            if (pos >= s.size()) return "";
        }
        std::string t;
        while (pos < s.size() && !std::isspace((unsigned char)s[pos]) && s[pos] != ',' && s[pos] != ';')
            t.push_back(s[pos++]);
        return t;
    };

    std::string tok;
    while (!(tok = nextTok()).empty()) {
        tok = trim_str(tok);
        if (tok.empty()) continue;
        std::string num = tok;
        if (num.size() > 2 && num[0] == '0' && (num[1] == 'x' || num[1] == 'X')) num = num.substr(2);
        for (char c : num) {
            if (!std::isxdigit((unsigned char)c)) { err = "invalid hex token: '" + tok + "'"; return false; }
        }
        try { out.push_back((uint32_t)std::stoul(num, nullptr, 16)); }
        catch (...) { err = "invalid hex token: '" + tok + "'"; return false; }
    }
    return true;
}

} // namespace risc201
