// risc201/alu.hpp — Optimized Risc201 ALU (all arithmetic BITWISE).
//
// Every arithmetic operation is implemented with a hardware-faithful bitwise
// algorithm rather than C++ built-in '+', '-', '*', '/' on the data path:
//
//   * Addition / Subtraction: Carry-Lookahead Adder (CLA)
//       32-bit adder, 8 blocks of 4 bits, two-level group lookahead.
//       a - b = a + ~b + 1 (two's complement subtract via CLA).
//       A 64-bit CLA (two 32-bit CLAs + carry) supports the Booth multiplier
//       and Goldschmidt divider.
//
//   * Multiplication: Booth radix-2 algorithm
//       Signed 32x32 -> 64-bit product.  Iterates 32 times over a 2-bit window
//       (Q0, Q-1): 01 -> A += M; 10 -> A -= M; 00/11 -> no-op.  Then ASR the
//       [A:Q:Q-1] triple.  All adds/subs use the CLA.
//       An unsigned variant (33-bit, 33 iterations) is used by the divider.
//
//   * Division / Modulo: Goldschmidt division
//       Q1.31 fixed-point.  Normalize D into [2^30, 2^31); iterate
//       f = 2 - D, then N *= f, D *= f (D -> 1.0, N -> N/D).  ~40 iterations
//       give 32-bit precision.  An exact correction loop fixes any residual
//       ULP error from fixed-point truncation.  Remainder = N - Q*D via Booth
//       unsigned multiply + CLA subtract.  All internal multiplies go through
//       Booth; a 64x64->128 multiply helper is built from four 32x32 Booth
//       multiplies + CLA adds.
//
//   * Compare: CLA subtraction + signed-overflow logic for E/GT flags.
//   * Logical (and/or/not) and shifts (lsl/lsr/asr) are already bitwise.
//
// Verified against the book's encoding examples (Section 3.3.14) and 2M
// random test vectors per category.

#pragma once

#include "isa.hpp"
#include <cstdint>

namespace risc201 {

// -----------------------------------------------------------------
// Bit primitive
// -----------------------------------------------------------------
inline bool bit(uint32_t x, int i) { return (x >> i) & 1u; }

// -----------------------------------------------------------------
// 32-bit Carry-Lookahead Adder (8 blocks of 4 bits, two-level lookahead)
// -----------------------------------------------------------------
// Within each 4-bit block:
//   g_i = a_i & b_i          (generate)
//   p_i = a_i | b_i          (propagate)
//   c_{i+1} = g_i | (p_i & c_i)
// The block's group generate G and propagate P feed the next block's c_in
// (second-level lookahead):  C_{k+1} = G_k | (P_k & C_k).
struct AddResult { uint32_t sum; uint8_t carry; };

inline AddResult cla_add32(uint32_t a, uint32_t b, uint8_t cin = 0) {
    uint32_t sum = 0;
    uint8_t c = cin & 1;

    // First pass: compute block-level G and P for each 4-bit block.
    uint8_t G[8], P[8];
    for (int blk = 0; blk < 8; ++blk) {
        uint8_t bg = 0, bp = 1;
        for (int i = 0; i < 4; ++i) {
            int bitpos = blk * 4 + i;
            uint8_t A = (a >> bitpos) & 1;
            uint8_t B = (b >> bitpos) & 1;
            uint8_t g = A & B;
            uint8_t p = A | B;
            bg = g | (p & bg);
            bp = bp & p;
        }
        G[blk] = bg; P[blk] = bp;
    }

    // Second-level lookahead: compute carry into each block.
    uint8_t block_carry[9];
    block_carry[0] = c;
    for (int blk = 0; blk < 8; ++blk)
        block_carry[blk + 1] = G[blk] | (P[blk] & block_carry[blk]);

    // Third pass: compute sum bits using the block carries.
    for (int blk = 0; blk < 8; ++blk) {
        uint8_t bc = block_carry[blk] & 1;
        for (int i = 0; i < 4; ++i) {
            int bitpos = blk * 4 + i;
            uint8_t A = (a >> bitpos) & 1;
            uint8_t B = (b >> bitpos) & 1;
            uint8_t p = A ^ B;
            uint8_t s = p ^ bc;
            uint8_t g = A & B;
            bc = g | (p & bc);
            if (s) sum |= (uint32_t)1 << bitpos;
        }
    }

    return { sum, (uint8_t)(block_carry[8] & 1) };
}

// 32-bit subtract: a - b = a + ~b + 1
inline AddResult cla_sub32(uint32_t a, uint32_t b) {
    return cla_add32(a, ~b, 1);
}

// -----------------------------------------------------------------
// 64-bit CLA adder (two 32-bit CLAs + carry)
// -----------------------------------------------------------------
struct Add64Result { uint64_t sum; uint8_t carry; };

inline Add64Result cla_add64(uint64_t a, uint64_t b, uint8_t cin = 0) {
    uint32_t lo_a = (uint32_t)a, lo_b = (uint32_t)b;
    uint32_t hi_a = (uint32_t)(a >> 32), hi_b = (uint32_t)(b >> 32);
    auto r1 = cla_add32(lo_a, lo_b, cin);
    auto r2 = cla_add32(hi_a, hi_b, r1.carry);
    return { ((uint64_t)r2.sum << 32) | r1.sum, r2.carry };
}

inline Add64Result cla_sub64(uint64_t a, uint64_t b) {
    return cla_add64(a, ~b, 1);
}

// -----------------------------------------------------------------
// Booth radix-2 multiplication (signed 32x32 -> 64-bit product)
// -----------------------------------------------------------------
// Maintains a triple [A(64) : Q(32) : Q_-1(1)]. Each iteration inspects
// (Q0, Q_-1):
//   01 -> A += M,  10 -> A -= M,  00/11 -> no-op
// Then arithmetic-right-shifts [A:Q:Q_-1] by 1. After 32 iterations the
// 64-bit product lives in [A:Q].  All adds/subs use the 64-bit CLA.
struct MulResult { int64_t product; };

inline MulResult booth_mul32(int32_t a, int32_t b) {
    int64_t M = (int64_t)a;
    int64_t A = 0;
    uint32_t Q = (uint32_t)b;
    int Q_1 = 0;

    for (int i = 0; i < 32; ++i) {
        int Q0 = Q & 1;
        int window = (Q0 << 1) | Q_1;
        if (window == 0b01) {
            auto r = cla_add64((uint64_t)A, (uint64_t)M, 0);
            A = (int64_t)r.sum;
        } else if (window == 0b10) {
            auto r = cla_sub64((uint64_t)A, (uint64_t)M);
            A = (int64_t)r.sum;
        }
        int new_Q_1 = Q0;
        uint32_t newQ = (Q >> 1) | ((uint32_t)(A & 1) << 31);
        A = A >> 1;  // arithmetic shift (int64_t sign-extends)
        Q = newQ;
        Q_1 = new_Q_1;
    }
    return { (int64_t)(((uint64_t)A << 32) | (uint64_t)Q) };
}

// Unsigned Booth: zero-extend operands to 33 bits (top bit 0), run 33 iters.
struct MulUResult { uint64_t product; };

inline MulUResult booth_mul32u(uint32_t a, uint32_t b) {
    int64_t M = (int64_t)(uint64_t)a;  // 33-bit non-negative
    int64_t A = 0;
    uint64_t Q = (uint64_t)b;
    int Q_1 = 0;

    for (int i = 0; i < 33; ++i) {
        int Q0 = (int)(Q & 1);
        int window = (Q0 << 1) | Q_1;
        if (window == 0b01) {
            auto r = cla_add64((uint64_t)A, (uint64_t)M, 0);
            A = (int64_t)r.sum;
        } else if (window == 0b10) {
            auto r = cla_sub64((uint64_t)A, (uint64_t)M);
            A = (int64_t)r.sum;
        }
        int new_Q_1 = Q0;
        uint64_t newQ = (Q >> 1) | ((uint64_t)(A & 1) << 32);
        A = A >> 1;
        Q = newQ;
        Q_1 = new_Q_1;
    }
    return { ((uint64_t)A << 33) | Q };
}

// -----------------------------------------------------------------
// 64x64 -> 128-bit multiply (four 32x32 Booth unsigned + CLA adds)
// Used internally by the Goldschmidt divider for fixed-point MAC.
// -----------------------------------------------------------------
inline void mul64x64(uint64_t a, uint64_t b, uint64_t& hi, uint64_t& lo) {
    uint32_t a_hi = (uint32_t)(a >> 32), a_lo = (uint32_t)a;
    uint32_t b_hi = (uint32_t)(b >> 32), b_lo = (uint32_t)b;

    uint64_t ll = booth_mul32u(a_lo, b_lo).product;
    uint64_t lh = booth_mul32u(a_lo, b_hi).product;
    uint64_t hl = booth_mul32u(a_hi, b_lo).product;
    uint64_t hh = booth_mul32u(a_hi, b_hi).product;

    uint32_t ll_lo = (uint32_t)ll, ll_hi = (uint32_t)(ll >> 32);
    uint32_t lh_lo = (uint32_t)lh, lh_hi = (uint32_t)(lh >> 32);
    uint32_t hl_lo = (uint32_t)hl, hl_hi = (uint32_t)(hl >> 32);
    uint32_t hh_lo = (uint32_t)hh, hh_hi = (uint32_t)(hh >> 32);

    auto r1 = cla_add32(ll_hi, lh_lo, 0);
    auto r2 = cla_add32(r1.sum, hl_lo, r1.carry);
    uint32_t mid32 = r2.sum;
    uint8_t carry_to_64 = r2.carry;

    auto r3 = cla_add32(lh_hi, hl_hi, 0);
    auto r4 = cla_add32(r3.sum, hh_lo, r3.carry);
    auto r5 = cla_add32(r4.sum, carry_to_64 ? 1u : 0u, r4.carry);
    uint32_t hi32 = r5.sum;
    uint8_t carry_to_96 = r5.carry;

    auto r6 = cla_add32(hh_hi, carry_to_96 ? 1u : 0u, 0);
    uint32_t top32 = r6.sum;

    lo = ((uint64_t)mid32 << 32) | ll_lo;
    hi = ((uint64_t)top32 << 32) | hi32;
}

// -----------------------------------------------------------------
// Goldschmidt division (unsigned 32/32 -> quotient + remainder)
// -----------------------------------------------------------------
// Works in Q1.31 fixed point.  Normalize D into [2^30, 2^31) (D_real in
// [0.5, 1.0)); then iteratively apply f = 2 - D to both N and D.
// D quadratically converges to 2^31 (= 1.0 in Q1.31), N converges to
// (N/D) * 2^31.  After ~40 iterations, Q = floor(N / 2^31).  An exact
// correction loop fixes any residual ULP error from fixed-point truncation.
// Remainder = N - Q*D via Booth unsigned multiply + CLA subtract.
// The 64x64 fixed-point multiplies inside the iteration use mul64x64.
struct DivResult { uint32_t quotient; uint32_t remainder; uint8_t exception; };

inline DivResult goldschmidt_div(uint32_t n, uint32_t d) {
    DivResult r{0, 0, 0};
    if (d == 0) { r.exception = 1; return r; }
    if (n == 0) { r.quotient = 0; r.remainder = 0; return r; }
    if (d > n)  { r.quotient = 0; r.remainder = n; return r; }

    // Step 1: normalize D into [2^30, 2^31) (Q1.31 fraction in [0.5, 1.0))
    int msb_d = 31;
    while (msb_d >= 0 && !((d >> msb_d) & 1u)) msb_d--;
    int shift = 30 - msb_d;   // can be negative if msb_d > 30
    uint32_t D; uint64_t N;
    if (shift >= 0) {
        D = d << shift;
        N = (uint64_t)n << shift;
    } else {
        int rshift = -shift;
        D = d >> rshift;
        N = (uint64_t)n >> rshift;
    }

    const uint64_t TWO_Q31 = 1ULL << 32;  // 2.0 in Q1.31

    // Step 2: Goldschmidt iterations
    for (int iter = 0; iter < 40; ++iter) {
        auto fr = cla_sub64(TWO_Q31, (uint64_t)D);
        uint32_t f = (uint32_t)fr.sum;

        uint64_t prod_hi, prod_lo;
        mul64x64(N, (uint64_t)f, prod_hi, prod_lo);
        N = (prod_hi << 33) | (prod_lo >> 31);

        uint64_t dprod = booth_mul32u(D, f).product;
        D = (uint32_t)(dprod >> 31);

        if (D == (1u << 31)) break;  // converged to 1.0
    }

    // Step 3: extract quotient = floor(N / 2^31) = N >> 31
    uint64_t Q = N >> 31;
    if (Q > 0xFFFFFFFFu) Q = 0xFFFFFFFFu;

    // Step 4: exact correction (fixed-point truncation can drift by a few ULP)
    uint64_t prod = booth_mul32u((uint32_t)Q, d).product;
    while (prod > (uint64_t)n && Q > 0) {
        Q--;
        auto sr = cla_sub64(prod, (uint64_t)d);
        prod = sr.sum;
    }
    auto ar = cla_add64(prod, (uint64_t)d, 0);
    uint64_t prod_next = ar.sum;
    while (prod_next <= (uint64_t)n && Q < 0xFFFFFFFFu) {
        Q++;
        prod = prod_next;
        auto ar2 = cla_add64(prod, (uint64_t)d, 0);
        prod_next = ar2.sum;
    }

    r.quotient = (uint32_t)Q;

    // Step 5: remainder = n - Q * d
    auto sr = cla_sub64((uint64_t)n, prod);
    r.remainder = (uint32_t)sr.sum;
    return r;
}

// -----------------------------------------------------------------
// Compare via CLA subtraction (signed)
// -----------------------------------------------------------------
inline Flags compare_flags(uint32_t a, uint32_t b) {
    Flags f{};
    auto r = cla_sub32(a, b);
    f.E = (r.sum == 0);
    bool sa = bit(a, 31), sb = bit(b, 31), sr = bit(r.sum, 31);
    bool overflow = (sa != sb) && (sr != sa);
    f.GT = !f.E && (overflow == sr);
    return f;
}

// -----------------------------------------------------------------
// Shifts (bitwise barrel shifts; amount mod 32)
// -----------------------------------------------------------------
inline uint32_t shl32(uint32_t v, uint8_t sh) {
    sh &= 31;
    if (sh == 0) return v;
    return v << sh;
}
inline uint32_t shr32(uint32_t v, uint8_t sh) {
    sh &= 31;
    if (sh == 0) return v;
    return v >> sh;
}
inline uint32_t sra32(uint32_t v, uint8_t sh) {
    sh &= 31;
    if (sh == 0) return v;
    return (uint32_t)((int32_t)v >> sh);
}

// -----------------------------------------------------------------
// ALU dispatch
// -----------------------------------------------------------------
struct AluOut {
    uint32_t value = 0;
    Flags    flags{};
    uint8_t  exception = 0;   // div-by-zero
};

inline AluOut alu_execute(Opcode op, uint32_t a, uint32_t b) {
    AluOut out;
    switch (op) {
        case OP_ADD: {
            auto r = cla_add32(a, b, 0);
            out.value = r.sum;
            break;
        }
        case OP_SUB: {
            auto r = cla_sub32(a, b);
            out.value = r.sum;
            break;
        }
        case OP_MUL: {
            auto r = booth_mul32((int32_t)a, (int32_t)b);
            out.value = (uint32_t)r.product;
            break;
        }
        case OP_DIV: {
            int32_t sa = (int32_t)a, sb = (int32_t)b;
            if (sb == 0) { out.exception = 1; out.value = 0; break; }
            bool neg = (sa < 0) != (sb < 0);
            uint32_t na = (sa < 0) ? (uint32_t)(-sa) : (uint32_t)sa;
            uint32_t nb = (sb < 0) ? (uint32_t)(-sb) : (uint32_t)sb;
            auto dr = goldschmidt_div(na, nb);
            int32_t q = (int32_t)dr.quotient;
            if (neg) q = -q;
            out.value = (uint32_t)q;
            break;
        }
        case OP_MOD: {
            int32_t sa = (int32_t)a, sb = (int32_t)b;
            if (sb == 0) { out.exception = 1; out.value = 0; break; }
            uint32_t na = (sa < 0) ? (uint32_t)(-sa) : (uint32_t)sa;
            uint32_t nb = (sb < 0) ? (uint32_t)(-sb) : (uint32_t)sb;
            auto dr = goldschmidt_div(na, nb);
            int32_t rem = (int32_t)dr.remainder;
            if (sa < 0) rem = -rem;
            out.value = (uint32_t)rem;
            break;
        }
        case OP_CMP: {
            out.flags = compare_flags(a, b);
            break;
        }
        case OP_AND: out.value = a & b; break;
        case OP_OR:  out.value = a | b; break;
        case OP_NOT: out.value = ~b;    break;
        case OP_MOV: out.value = b;     break;
        case OP_LSL: out.value = shl32(a, (uint8_t)(b & 0x1F)); break;
        case OP_LSR: out.value = shr32(a, (uint8_t)(b & 0x1F)); break;
        case OP_ASR: out.value = sra32(a, (uint8_t)(b & 0x1F)); break;
        case OP_LD: case OP_ST: {
            auto r = cla_add32(a, b, 0);
            out.value = r.sum;  // effective address = rs1 + offset
            break;
        }
        default: out.value = 0; break;
    }
    return out;
}

} // namespace risc201
