// risc201/core.hpp — Register file, main memory, runtime exceptions,
// and full-descending stack subsystem with boundary safety + ASCII visualizer.
//
// PC is kept in the RegisterFile struct (alongside the 16 registers and
// flags) so the microcode sequencer can access it uniformly. The micro_pc
// field is exposed for the debugger.
//
// Risc201 convention:
//   r0..r13 = general purpose
//   r14 = sp (stack pointer)
//   r15 = ra (return address)
//   PC is a separate register (NOT r15)
//   Flags: E (equal), GT (greater-than) — set only by cmp

#pragma once

#include "isa.hpp"
#include <array>
#include <string>
#include <sstream>
#include <vector>
#include <cstdint>
#include <cstdio>

namespace risc201 {

// ---------------- Runtime exceptions ----------------
enum class ExKind : uint8_t {
    None = 0,
    DivByZero,
    StackOverflow,
    StackUnderflow,
    StackMisaligned,
    StackOutOfBounds,
    IllegalInstruction,
    Breakpoint,
    Halt,
};

struct RiscException {
    ExKind kind = ExKind::None;
    uint32_t pc = 0;
    std::string message;
};

inline const char* exkind_name(ExKind k) {
    switch (k) {
        case ExKind::None:               return "none";
        case ExKind::DivByZero:          return "DivisionByZero";
        case ExKind::StackOverflow:      return "StackOverflow";
        case ExKind::StackUnderflow:     return "StackUnderflow";
        case ExKind::StackMisaligned:    return "StackMisaligned";
        case ExKind::StackOutOfBounds:   return "StackOutOfBounds";
        case ExKind::IllegalInstruction: return "IllegalInstruction";
        case ExKind::Breakpoint:         return "Breakpoint";
        case ExKind::Halt:               return "Halt";
    }
    return "unknown";
}

// ---------------- Register file ----------------
// Risc201: r0..r13 GP, r14=sp, r15=ra. PC is separate. Flags: E, GT.
struct RegisterFile {
    std::array<uint32_t, REG_COUNT> r{};
    Flags flags{};
    uint32_t pc = 0;        // program counter (separate from r0..r15)
    uint32_t micro_pc = 0;  // exposed for the debugger

    void reset() { r.fill(0); flags.raw = 0; pc = 0; micro_pc = 0; }

    uint32_t read(int idx) const { return r[idx & 0xF]; }
    void write(int idx, uint32_t v) { r[idx & 0xF] = v; }

    uint32_t& sp() { return r[SP_REG]; }
    uint32_t& ra() { return r[RA_REG]; }
    uint32_t  sp() const { return r[SP_REG]; }
    uint32_t  ra() const { return r[RA_REG]; }

    void init_stack_pointer(uint32_t top) { r[SP_REG] = top; }
};

// ---------------- Main memory (byte-addressable, little-endian) ----------------
struct Memory {
    std::vector<uint8_t> bytes;
    uint32_t size_bytes;

    explicit Memory(uint32_t size = MEM_SIZE * 4) : size_bytes(size) {
        bytes.assign(size, 0);
    }

    uint8_t read_byte(uint32_t addr) const {
        if (addr >= size_bytes) return 0;
        return bytes[addr];
    }
    void write_byte(uint32_t addr, uint8_t v) {
        if (addr >= size_bytes) return;
        bytes[addr] = v;
    }
    uint32_t read_word(uint32_t addr) const {
        return (uint32_t)read_byte(addr)
             | ((uint32_t)read_byte(addr + 1) << 8)
             | ((uint32_t)read_byte(addr + 2) << 16)
             | ((uint32_t)read_byte(addr + 3) << 24);
    }
    void write_word(uint32_t addr, uint32_t v) {
        write_byte(addr,     (uint8_t)(v & 0xFF));
        write_byte(addr + 1, (uint8_t)((v >> 8) & 0xFF));
        write_byte(addr + 2, (uint8_t)((v >> 16) & 0xFF));
        write_byte(addr + 3, (uint8_t)((v >> 24) & 0xFF));
    }

    void load_image(const std::vector<uint32_t>& words, uint32_t base = 0) {
        for (size_t i = 0; i < words.size(); ++i)
            write_word(base + (uint32_t)i * 4, words[i]);
    }

    std::string dump(uint32_t start, int count) const {
        std::ostringstream os;
        for (int i = 0; i < count; ++i) {
            uint32_t a = start + (uint32_t)i * 4;
            uint32_t w = read_word(a);
            char buf[64];
            std::snprintf(buf, sizeof(buf), "0x%06x: 0x%08x\n", a, w);
            os << buf;
        }
        return os.str();
    }
};

// ---------------- Stack subsystem (full-descending) ----------------
constexpr uint32_t STACK_BASE  = 0x0000FFFCu;
constexpr uint32_t STACK_LIMIT = 0x00008000u;

struct Stack {
    Memory& mem;
    RegisterFile& rf;
    bool enabled = true;
    uint32_t low_water  = STACK_BASE;
    uint32_t high_water = STACK_BASE;

    Stack(Memory& m, RegisterFile& r) : mem(m), rf(r) {}

    RiscException push(uint32_t value) {
        uint32_t sp = rf.sp();
        uint32_t new_sp = sp - 4;
        if (enabled && new_sp < STACK_LIMIT) {
            return { ExKind::StackOverflow, rf.pc,
                     "SP would cross stack floor (LIMIT=0x"
                     + ([](){char b[16]; std::snprintf(b,sizeof(b),"%x",STACK_LIMIT); return std::string(b);}())
                     + ")" };
        }
        if (enabled && (new_sp & 3) != 0) {
            return { ExKind::StackMisaligned, rf.pc, "SP not word-aligned" };
        }
        rf.sp() = new_sp;
        mem.write_word(new_sp, value);
        if (new_sp < high_water) high_water = new_sp;
        return {};
    }

    RiscException pop(uint32_t& out_val) {
        uint32_t sp = rf.sp();
        if (enabled && sp > STACK_BASE) {
            return { ExKind::StackUnderflow, rf.pc, "SP would cross stack ceiling" };
        }
        if (enabled && (sp & 3) != 0) {
            return { ExKind::StackMisaligned, rf.pc, "SP not word-aligned" };
        }
        out_val = mem.read_word(sp);
        rf.sp() = sp + 4;
        if (sp > low_water) low_water = sp;
        return {};
    }

    bool verify() const {
        uint32_t sp = rf.sp();
        return sp >= STACK_LIMIT && sp <= STACK_BASE && (sp & 3) == 0;
    }

    std::string visualize(uint32_t depth = 16) const {
        std::ostringstream os;
        uint32_t sp = rf.sp();
        uint32_t start = sp;
        uint32_t end = (sp + depth * 4 > STACK_BASE) ? STACK_BASE : (sp + depth * 4 - 4);
        os << "  +----------+----------+-----------------------+\n";
        os << "  |  ADDR    |  VALUE   |  NOTES                |\n";
        os << "  +----------+----------+-----------------------+\n";
        for (uint32_t a = start; a <= end; a += 4) {
            uint32_t v = mem.read_word(a);
            std::string note;
            if (a == sp) note += "<- SP";
            char line[128];
            std::snprintf(line, sizeof(line),
                "  | 0x%06X | 0x%08X | %-21s |\n",
                (unsigned)a, (unsigned)v, note.c_str());
            os << line;
        }
        os << "  +----------+----------+-----------------------+\n";
        char foot[128];
        std::snprintf(foot, sizeof(foot),
            "  high_water=0x%06X low_water=0x%06X  limit=0x%06X base=0x%06X\n",
            (unsigned)high_water, (unsigned)low_water,
            (unsigned)STACK_LIMIT, (unsigned)STACK_BASE);
        os << foot;
        return os.str();
    }
};

} // namespace risc201
