// risc201/isa.hpp — Risc201 ISA: opcodes, formats, encoding helpers.
//
// Risc201 is the 21-instruction RISC ISA from Sarangi's "Basic Computer
// Architecture" (Chapter 3). It has:
//   * 16 registers (r0..r15), 32-bit each. r14 = sp, r15 = ra.
//   * Internal flags: E (equal), GT (greater-than). Set only by `cmp`.
//   * 32-bit fixed-width instructions, 3 encoding formats:
//       branch   : op(5) | offset(27)
//       register : op(5) | I=0(1) | rd(4) | rs1(4) | rs2(4)
//       immediate: op(5) | I=1(1) | rd(4) | rs1(4) | imm(18) = modifier(2)+const(16)
//   * Little-endian, byte-addressable Von-Neumann memory.
//   * Immediate modifiers (u/h suffix on ALU ops except shifts):
//       default = sign-extend 16->32; u = zero-extend; h = upper 16 bits.
//
// This file is the single source of truth for the ISA across the whole project.

#pragma once

#include <cstdint>
#include <string>
#include <stdexcept>
#include <sstream>
#include <ios>
#include <cctype>

namespace risc201 {

constexpr int WORD_BITS     = 32;
constexpr int REG_COUNT     = 16;
constexpr int MEM_SIZE      = 1 << 16;   // 64K words = 256 KiB
constexpr int INSTR_SIZE    = 4;         // bytes per instruction
constexpr int SP_REG        = 14;        // r14 = stack pointer
constexpr int RA_REG        = 15;        // r15 = return address
constexpr int NUM_INSTR     = 21;        // total distinct opcodes

// Opcode enumeration (Table 3.10 in the book). 5-bit opcode, MSB-first.
enum Opcode : uint8_t {
    OP_ADD  = 0x00, // 00000  Rd = Rs1 + Rs2/imm
    OP_SUB  = 0x01, // 00001  Rd = Rs1 - Rs2/imm
    OP_MUL  = 0x02, // 00010  Rd = Rs1 * Rs2/imm  (Booth)
    OP_DIV  = 0x03, // 00011  Rd = Rs1 / Rs2/imm  (Goldschmidt)
    OP_MOD  = 0x04, // 00100  Rd = Rs1 % Rs2/imm
    OP_CMP  = 0x05, // 00101  flags = Rs1 - Rs2/imm
    OP_AND  = 0x06, // 00110  Rd = Rs1 & Rs2/imm
    OP_OR   = 0x07, // 00111  Rd = Rs1 | Rs2/imm
    OP_NOT  = 0x08, // 01000  Rd = ~Rs2/imm
    OP_MOV  = 0x09, // 01001  Rd = Rs2/imm
    OP_LSL  = 0x0A, // 01010  Rd = Rs1 << Rs2/imm
    OP_LSR  = 0x0B, // 01011  Rd = Rs1 >> Rs2/imm  (logical)
    OP_ASR  = 0x0C, // 01100  Rd = Rs1 >> Rs2/imm  (arithmetic)
    OP_NOP  = 0x0D, // 01101  no operation
    OP_LD   = 0x0E, // 01110  Rd = MEM[Rs1 + imm]
    OP_ST   = 0x0F, // 01111  MEM[Rs1 + imm] = Rd
    OP_BEQ  = 0x10, // 10000  branch if flags.E
    OP_BGT  = 0x11, // 10001  branch if flags.GT
    OP_B    = 0x12, // 10010  unconditional branch
    OP_CALL = 0x13, // 10011  ra = PC+4; PC = target
    OP_RET  = 0x14, // 10100  PC = ra
    OP_INVALID = 0xFF,
};

enum class Fmt : uint8_t { BRANCH, REGISTER, IMMEDIATE, NONE };

// Immediate modifier (Section 3.3.13)
enum class Modifier : uint8_t {
    DEFAULT = 0, // sign-extend  (modifier bits 00)
    U       = 1, // zero-extend  (modifier bits 01, suffix 'u')
    H       = 2, // high half    (modifier bits 10, suffix 'h')
};

// Flags register — only `cmp` writes these; `beq`/`bgt` read them.
union Flags {
    struct { uint8_t E : 1; uint8_t GT : 1; };
    uint8_t raw = 0;
};

// ---- Format detection ----
inline bool is_branch_format(Opcode op) {
    return op == OP_B || op == OP_BEQ || op == OP_BGT ||
           op == OP_CALL || op == OP_RET || op == OP_NOP;
}

inline Fmt primary_format(Opcode op) {
    if (is_branch_format(op)) return Fmt::BRANCH;
    // All non-branch instructions support both register and immediate formats
    // (decided by the I bit at decode time).
    return Fmt::REGISTER;
}

// ---- Field extraction (bit numbering: 31 = MSB .. 0 = LSB) ----
inline uint8_t  get_op (uint32_t w) { return (w >> 27) & 0x1F; }
inline uint8_t  get_i  (uint32_t w) { return (w >> 26) & 0x1;  }
inline uint8_t  get_rd (uint32_t w) { return (w >> 22) & 0xF;  }
inline uint8_t  get_rs1(uint32_t w) { return (w >> 18) & 0xF;  }
inline uint8_t  get_rs2(uint32_t w) { return (w >> 14) & 0xF;  }
inline uint32_t get_imm18(uint32_t w) { return w & 0x3FFFF; }
inline uint8_t  get_mod (uint32_t w) { return (w >> 16) & 0x3; }
inline uint16_t get_imm16(uint32_t w) { return w & 0xFFFF; }
inline uint32_t get_offset(uint32_t w) { return w & 0x7FFFFFF; }

// ---- Field insertion ----
inline uint32_t enc_op(Opcode op)   { return (uint32_t)(op & 0x1F) << 27; }
inline uint32_t enc_i(bool imm)     { return (uint32_t)imm << 26; }
inline uint32_t enc_rd(uint8_t rd)  { return (uint32_t)(rd & 0xF) << 22; }
inline uint32_t enc_rs1(uint8_t rs) { return (uint32_t)(rs & 0xF) << 18; }
inline uint32_t enc_rs2(uint8_t rs) { return (uint32_t)(rs & 0xF) << 14; }
inline uint32_t enc_offset(int32_t off) { return (uint32_t)off & 0x7FFFFFF; }
inline uint32_t enc_imm(Modifier m, uint16_t c) {
    return ((uint32_t)((uint8_t)m & 0x3) << 16) | (uint32_t)c;
}

// ---- Sign extension ----
inline int32_t sign_extend(uint32_t value, int bits) {
    uint32_t m = 1u << (bits - 1);
    return (int32_t)((value ^ m) - m);
}

// Expand a 16-bit constant + modifier into a 32-bit value (Section 3.3.13)
inline uint32_t expand_immediate(uint16_t constant, Modifier mod) {
    switch (mod) {
        case Modifier::DEFAULT: return (uint32_t)(int32_t)(int16_t)constant;
        case Modifier::U:       return (uint32_t)constant;
        case Modifier::H:       return ((uint32_t)constant) << 16;
    }
    return (uint32_t)(int32_t)(int16_t)constant;
}

// ---- Decoded instruction (the "instruction packet") ----
struct Decoded {
    uint32_t  word = 0;
    Opcode    op = OP_NOP;
    Fmt       format = Fmt::BRANCH;
    Modifier  mod = Modifier::DEFAULT;
    bool      is_immediate = false;  // I bit
    uint8_t   rd = 0;
    uint8_t   rs1 = 0;
    uint8_t   rs2 = 0;
    int32_t   imm = 0;        // expanded 32-bit immediate
    int32_t   offset = 0;     // sign-extended 27-bit branch offset (in words)

    bool is_branch()    const { return is_branch_format(op); }
    bool writes_reg()   const;
    bool sets_flags()   const { return op == OP_CMP; }
    bool reads_mem()    const { return op == OP_LD; }
    bool writes_mem()   const { return op == OP_ST; }
    bool is_uncond_br() const;
    bool is_nop()       const { return op == OP_NOP; }
};

// ---- Encode / decode ----
inline Decoded decode(uint32_t word) {
    Decoded d;
    d.word = word;
    d.op = (Opcode)get_op(word);

    if (d.op > OP_RET) { d.op = OP_NOP; d.format = Fmt::BRANCH; return d; }

    if (is_branch_format(d.op)) {
        d.format = Fmt::BRANCH;
        d.offset = sign_extend(get_offset(word), 27);
        return d;
    }

    d.is_immediate = (get_i(word) == 1);
    d.format = d.is_immediate ? Fmt::IMMEDIATE : Fmt::REGISTER;
    d.rd  = get_rd(word);
    d.rs1 = get_rs1(word);
    d.rs2 = get_rs2(word);
    d.mod = (Modifier)get_mod(word);
    if (d.is_immediate) {
        d.imm = (int32_t)expand_immediate(get_imm16(word), d.mod);
    }
    return d;
}

inline uint32_t encode(const Decoded& d) {
    uint32_t w = enc_op(d.op);
    if (d.format == Fmt::BRANCH) {
        w |= enc_offset(d.offset);
        return w;
    }
    w |= enc_i(d.is_immediate);
    w |= enc_rd(d.rd);
    w |= enc_rs1(d.rs1);
    if (d.is_immediate) {
        w |= enc_imm(d.mod, (uint16_t)(d.imm & 0xFFFF));
    } else {
        w |= enc_rs2(d.rs2);
    }
    return w;
}

inline Decoded make_nop() {
    Decoded d;
    d.word = enc_op(OP_NOP);
    d.op = OP_NOP;
    d.format = Fmt::BRANCH;
    return d;
}

// ---- Instruction metadata (Table 3.10 + semantics Sections 3.3.3–3.3.12) ----
struct InstrInfo {
    const char* mnem;
    Opcode op;
    bool writes_reg;
    bool supports_mod;   // accepts 'u'/'h' immediate modifiers (all ALU except shifts)
    bool uncond_branch;
};

inline const InstrInfo* info_by_opcode(Opcode op) {
    static const InstrInfo table[] = {
        {"add",  OP_ADD,  true,  true,  false},
        {"sub",  OP_SUB,  true,  true,  false},
        {"mul",  OP_MUL,  true,  true,  false},
        {"div",  OP_DIV,  true,  true,  false},
        {"mod",  OP_MOD,  true,  true,  false},
        {"cmp",  OP_CMP,  false, true,  false},
        {"and",  OP_AND,  true,  true,  false},
        {"or",   OP_OR,   true,  true,  false},
        {"not",  OP_NOT,  true,  true,  false},
        {"mov",  OP_MOV,  true,  true,  false},
        {"lsl",  OP_LSL,  true,  false, false},
        {"lsr",  OP_LSR,  true,  false, false},
        {"asr",  OP_ASR,  true,  false, false},
        {"nop",  OP_NOP,  false, false, false},
        {"ld",   OP_LD,   true,  false, false},
        {"st",   OP_ST,   false, false, false},
        {"beq",  OP_BEQ,  false, false, false},
        {"bgt",  OP_BGT,  false, false, false},
        {"b",    OP_B,    false, false, true },
        {"call", OP_CALL, true,  false, true },
        {"ret",  OP_RET,  false, false, true },
    };
    for (const auto& i : table) if (i.op == op) return &i;
    return nullptr;
}

inline const InstrInfo* info_by_mnemonic(const std::string& base) {
    for (int o = 0; o <= OP_RET; ++o) {
        auto* i = info_by_opcode((Opcode)o);
        if (i && base == i->mnem) return i;
    }
    return nullptr;
}

inline const char* opcode_mnemonic(Opcode op) {
    auto* i = info_by_opcode(op);
    return i ? i->mnem : "???";
}

inline bool Decoded::writes_reg() const {
    auto* i = info_by_opcode(op);
    return i && i->writes_reg;
}
inline bool Decoded::is_uncond_br() const {
    auto* i = info_by_opcode(op);
    return i && i->uncond_branch;
}

// Parse a mnemonic that may carry 'u'/'h' suffix into (base, modifier).
inline bool parse_mnemonic(std::string tok, std::string& base, Modifier& mod) {
    mod = Modifier::DEFAULT;
    if (tok.size() > 1) {
        char last = tok.back();
        if (last == 'u' || last == 'h') {
            std::string cand = tok.substr(0, tok.size() - 1);
            auto* info = info_by_mnemonic(cand);
            if (info && info->supports_mod) {
                base = cand;
                mod = (last == 'u') ? Modifier::U : Modifier::H;
                return true;
            }
        }
    }
    auto* info = info_by_mnemonic(tok);
    if (info) { base = tok; mod = Modifier::DEFAULT; return true; }
    return false;
}

// Register name <-> number: "r0".."r15", "sp"(r14), "ra"(r15)
inline int parse_register(const std::string& s, std::string* err = nullptr) {
    std::string lower = s;
    for (auto& c : lower) c = (char)tolower(c);
    if (lower == "sp") return SP_REG;
    if (lower == "ra") return RA_REG;
    if (lower.size() >= 2 && lower[0] == 'r') {
        bool digits = true;
        for (size_t i = 1; i < lower.size(); ++i)
            if (!isdigit((unsigned char)lower[i])) { digits = false; break; }
        if (digits) {
            int n = std::stoi(lower.substr(1));
            if (n >= 0 && n < REG_COUNT) return n;
        }
    }
    if (err) *err = "invalid register name: '" + s + "'";
    return -1;
}

inline std::string register_name(int r) {
    if (r == SP_REG) return "sp";
    if (r == RA_REG) return "ra";
    return std::string("r") + std::to_string(r);
}

// Disassemble a decoded instruction to assembly text.
inline std::string disasm_text(const Decoded& d, uint32_t pc) {
    auto* info = info_by_opcode(d.op);
    if (!info) return ".word 0x" + std::to_string(d.word);

    std::ostringstream os;
    os << info->mnem;
    if (info->supports_mod && d.is_immediate) {
        if (d.mod == Modifier::U) os << 'u';
        else if (d.mod == Modifier::H) os << 'h';
    }

    switch (d.op) {
        case OP_NOP: case OP_RET:
            break;
        case OP_B: case OP_BEQ: case OP_BGT: case OP_CALL: {
            uint32_t target = pc + (uint32_t)(d.offset * 4);
            os << " 0x" << std::hex << target << std::dec;
            break;
        }
        case OP_MOV: case OP_NOT:
            os << ' ' << register_name(d.rd) << ", "
               << (d.is_immediate ? std::to_string(d.imm) : register_name(d.rs2));
            break;
        case OP_CMP:
            os << ' ' << register_name(d.rs1) << ", "
               << (d.is_immediate ? std::to_string(d.imm) : register_name(d.rs2));
            break;
        case OP_LD: case OP_ST:
            os << ' ' << register_name(d.rd) << ", " << d.imm
               << '[' << register_name(d.rs1) << ']';
            break;
        default:
            os << ' ' << register_name(d.rd) << ", " << register_name(d.rs1) << ", "
               << (d.is_immediate ? std::to_string(d.imm) : register_name(d.rs2));
            break;
    }
    return os.str();
}

} // namespace risc201
