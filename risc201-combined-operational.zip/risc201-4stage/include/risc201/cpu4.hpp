// risc201/cpu4.hpp — 4-stage Risc201 CPU (OPERATIONAL pipelined, vertical microcode).
//
// CPU4V drives a true overlapping 4-stage pipeline (IF -> ID -> EX -> WB;
// operand fetch fused into ID, memory access fused into EX) controlled
// END-TO-END by the vertical microcode ROM (32-bit µword, 1 action per
// µop, ~4 µops/macro).
//
//   IF  : µop FETCH_IR   — IR <- MEM[PC]; PC <- PC+4 (or branch target).
//   ID  : µops DECODE, OF_READ — decode, dispatch, read regfile (fwd).
//   EX  : µops ALU_OP, SET_FLAGS, COMPUTE_TARGET, COND_BRANCH,
//              PC_LOAD_TARGET, LINK_RA, MEM_READ, MEM_WRITE.
//   WB  : µop REG_WRITE  — R[rd] <- result; retirement (JMP_MICRO->FETCH).
//
// The SAME vertical ROM µwords are used as in the sequential model; only
// the µop->stage assignment differs from the 6-stage design (OF_READ is
// interpreted by ID, MEM_READ/MEM_WRITE by EX).
//
// WHAT MAKES IT OPERATIONAL:
//   * Each in-flight instruction carries its own µPC; every stage is a
//     vertical µop interpreter for its assigned µops; several instructions
//     execute their microcode sequences concurrently.
//   * IF fetches one instruction per cycle, WB retires one per cycle.
//   * Every control signal still comes from the ROM — no hardwired logic.
//
// HAZARD HANDLING (ROM-driven):
//   * RAW hazards: fully bypassed into ID (EX same-cycle result — including
//     load data, EX/WB result, regfile write-first) -> ZERO stalls, even
//     for load-use (the fused ID stage reads one cycle after EX produced
//     the load data, so the same-cycle bypass always reaches it).
//   * Flags & ra: committed by EX-stage µops (SET_FLAGS / LINK_RA).
//   * PC-redirecting µops execute in EX: younger packets are still in
//     IF/ID + ID/EX (fetch/decode only), so squashing is precise.
//     Taken-branch penalty = 2 bubbles; not-taken = 0.

#pragma once

#include "isa.hpp"
#include "alu.hpp"
#include "core.hpp"
#include <array>
#include <vector>
#include <string>
#include <cstdint>

namespace risc201 {

// =====================================================================
// Part 1 — VERTICAL microcode (32-bit µword, 1 action per µop)
// (µop set unified with the 6-stage CPU: OF_READ + ALU_OP replace the
//  sequential model's fused ALU_OP_R/ALU_OP_MOV µwords.)
// =====================================================================

enum class VAction : uint8_t {
    NOP = 0,
    FETCH_IR,        // IF  : IR = MEM[PC]; PC += 4 (or redirected target)
    DECODE,          // ID  : µPC = dispatch_table[opcode]; extract fields
    OF_READ,         // ID  : read rs1, rs2 (or expand imm) into A, B, op2
    ALU_OP,          // EX  : ALU(arg1=opcode); srcA = A, srcB = B
    REG_WRITE,       // WB  : R[rd] = result
    SET_FLAGS,       // EX  : flags = ALUout.flags   (early commit)
    MEM_READ,        // EX  : MAR = A + imm; MDR = MEM[MAR]; result = MDR
    MEM_WRITE,       // EX  : MAR = A + imm; MEM[MAR] = op2
    COMPUTE_TARGET,  // EX  : mdr = pkt.pc + offset*4
    PC_LOAD_TARGET,  // EX  : PC = mdr (b/call) or PC = R[ra] (ret) + redirect
    LINK_RA,         // EX  : R[ra] = pkt.pc + 4 (call link; early commit)
    COND_BRANCH,     // EX  : if cond(flags) then PC = mdr + redirect
    HALT,            // stop CPU
    JMP_MICRO,       // µPC = (arg1<<8 | arg2); -> FETCH marks retirement
};

struct VMicroOp {
    uint8_t action;   // VAction
    uint8_t arg1;
    uint8_t arg2;
    uint8_t cond;     // condition code for COND_BRANCH
};

inline const char* vaction_name(VAction a) {
    switch (a) {
        case VAction::NOP:            return "NOP";
        case VAction::FETCH_IR:       return "FETCH_IR";
        case VAction::DECODE:         return "DECODE";
        case VAction::OF_READ:       return "OF_READ";
        case VAction::ALU_OP:        return "ALU_OP";
        case VAction::REG_WRITE:     return "REG_WRITE";
        case VAction::SET_FLAGS:     return "SET_FLAGS";
        case VAction::MEM_READ:      return "MEM_READ";
        case VAction::MEM_WRITE:     return "MEM_WRITE";
        case VAction::COMPUTE_TARGET:return "COMPUTE_TGT";
        case VAction::PC_LOAD_TARGET:return "PC_LOAD_TGT";
        case VAction::LINK_RA:       return "LINK_RA";
        case VAction::COND_BRANCH:   return "COND_BRANCH";
        case VAction::HALT:          return "HALT";
        case VAction::JMP_MICRO:     return "JMP_MICRO";
    }
    return "?";
}

enum VCond : uint8_t {
    VC_ALWAYS = 0,
    VC_E, VC_NE, VC_GT, VC_NGT,
};

inline bool eval_vcond(VCond c, Flags f) {
    switch (c) {
        case VC_ALWAYS: return true;
        case VC_E:   return f.E;
        case VC_NE:  return !f.E;
        case VC_GT:  return f.GT;
        case VC_NGT: return !f.GT;
    }
    return false;
}

// =====================================================================
// Part 2 — Stage µop assignment (4-stage control plan)
// =====================================================================

inline bool upc_is_if_local(VAction a) { return a == VAction::FETCH_IR; }
inline bool upc_is_id_local(VAction a) {
    return a == VAction::DECODE || a == VAction::OF_READ;  // fused operand fetch
}
inline bool upc_is_ex_local(VAction a) {
    return a == VAction::ALU_OP || a == VAction::SET_FLAGS ||
           a == VAction::MEM_READ || a == VAction::MEM_WRITE ||
           a == VAction::COMPUTE_TARGET || a == VAction::COND_BRANCH ||
           a == VAction::PC_LOAD_TARGET || a == VAction::LINK_RA;
}
inline bool upc_is_wb_local(VAction a) { return a == VAction::REG_WRITE; }

// Pipeline order of each µop (IF=0, ID=1, EX=2, WB=3); -1 = sequencer-only.
// Every ROM routine is emitted in this order, so a packet in stage S has
// always consumed every µop of order < S.
inline int upc_stage_order(VAction a) {
    if (a == VAction::FETCH_IR) return 0;
    if (upc_is_id_local(a))     return 1;
    if (upc_is_ex_local(a))     return 2;
    if (upc_is_wb_local(a))     return 3;
    return -1;
}

// =====================================================================
// Part 3 — Instruction packet (travels through the pipeline registers)
// =====================================================================

struct PipePkt {
    uint32_t inst_word  = 0;
    uint32_t pc         = 0;       // instruction's own address
    Opcode   op         = OP_NOP;
    uint8_t  rd         = 0;
    uint8_t  rs1        = 0;
    uint8_t  rs2        = 0;
    int32_t  imm        = 0;
    Modifier mod        = Modifier::DEFAULT;
    bool     is_imm     = false;
    int32_t  offset     = 0;
    bool     writes_back= false;
    uint8_t  upc        = 0;       // <- per-instruction micro program counter
    uint32_t A           = 0;      // operand 1 (rs1 value), captured in ID
    uint32_t B           = 0;      // operand 2 (rs2 value or expanded imm)
    uint32_t op2         = 0;      // store data (rd value) for st
    uint32_t result      = 0;      // ALU result or loaded data
    bool     result_ready= false;  // result available for bypass
    bool     is_load     = false;
    bool     is_store    = false;
    bool     valid       = false;
    uint64_t fetch_cycle = 0;
};

using IF_ID = PipePkt;
using ID_EX = PipePkt;
using EX_WB = PipePkt;

// =====================================================================
// Part 4 — ROM container (same layout as the sequential model)
// =====================================================================

constexpr int VROM_SIZE = 256;

struct VerticalMicrocode {
    std::array<VMicroOp, VROM_SIZE> rom{};
    std::array<uint8_t, 32> dispatch{};
    VerticalMicrocode() { build(); }
private:
    void build();
};

// =====================================================================
// Part 5 — CPU4V (4-stage operational pipeline, vertical microcode)
// =====================================================================

// Synthetic clock-period model: critical path = t_EX ≈ 1050 ps (ALU +
// memory fused) -> 1000 ps (1.0 ns) per cycle. Unchanged from the
// sequential model.
constexpr uint64_t CYCLE_PERIOD_PS = 1000;  // 4-stage clock period: 1.0 ns

class CPU4V {
public:
    Memory       mem;
    RegisterFile rf{};
    Stack        stack;
    VerticalMicrocode vuc;

    // Pipeline registers — each holds one instruction packet.
    IF_ID  if_id;
    ID_EX  id_ex;
    EX_WB  ex_wb;
    EX_WB  wb_retire;     // last retired packet (debugger view)

    bool     halted = false;
    uint64_t cycle  = 0;
    uint64_t inst_retired = 0;

    // Hazard-control signals
    bool     flush_pending = false;
    uint32_t redirect_target = 0;
    bool     stream_end    = false;

    // Shared datapath registers (debugger-visible)
    AluOut   alu_out{};
    uint32_t mar = 0;
    uint32_t mdr = 0;

    // Statistics
    uint64_t redirect_count  = 0;
    uint64_t flush_events    = 0;
    uint64_t flushed_insts   = 0;
    uint64_t bypass_hits     = 0;
    uint64_t load_stall_cycles = 0;   // always 0: 4-stage bypasses load-use
    uint64_t max_in_flight   = 0;

    std::vector<uint32_t> breakpoints;

    CPU4V() : mem(MEM_SIZE * 4), stack(mem, rf) {
        rf.pc = 0; rf.sp() = STACK_BASE;
    }

    void load_program(const std::vector<uint32_t>& words, uint32_t at = 0) {
        for (uint32_t i = 0; i < words.size() && at + i * 4 < mem.size_bytes; ++i)
            mem.write_word(at + i * 4, words[i]);
        rf.pc = at; rf.sp() = STACK_BASE; rf.ra() = 0;
        if_id = PipePkt{}; id_ex = PipePkt{}; ex_wb = PipePkt{}; wb_retire = PipePkt{};
        halted = false; cycle = 0; inst_retired = 0;
        flush_pending = false; redirect_target = 0; stream_end = false;
        alu_out = {}; mar = 0; mdr = 0;
        redirect_count = 0; flush_events = 0; flushed_insts = 0;
        bypass_hits = 0; load_stall_cycles = 0; max_in_flight = 0;
    }

    RiscException step_cycle();
    RiscException step_micro();
    RiscException step();

    std::string pipeline_snapshot() const;
    std::string regfile_snapshot() const;
    std::string micro_snapshot() const;
    std::string cpu_name() const { return "Risc201-4stage"; }
    uint8_t  current_upc() const;

    uint64_t cycle_period_ps() const { return CYCLE_PERIOD_PS; }
    uint64_t elapsed_time_ps() const { return cycle * CYCLE_PERIOD_PS; }

private:
    int  wb_step(RiscException& ex);
    void ex_step(RiscException& ex);
    void id_step();
    void if_step(uint32_t fetch_pc);

    uint32_t fwd_id(uint8_t reg, uint32_t rf_val);   // ID-stage bypass muxes

    bool     ex_fwd_valid = false;  // EX produced a result this cycle
    uint8_t  ex_fwd_rd    = 0;
    uint32_t ex_fwd_val   = 0;

    void count_in_flight();
};

} // namespace risc201
