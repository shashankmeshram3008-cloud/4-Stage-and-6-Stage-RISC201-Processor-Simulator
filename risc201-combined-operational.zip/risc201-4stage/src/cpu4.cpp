// risc201/src/cpu4.cpp — 4-stage Risc201 CPU (OPERATIONAL pipelined, vertical µcode).
//
// Pipeline: IF -> ID -> EX -> WB (instructions OVERLAP)
//   ID interprets DECODE + OF_READ (operand fetch fused into decode);
//   EX interprets ALU_OP / SET_FLAGS / COMPUTE_TARGET / COND_BRANCH /
//        PC_LOAD_TARGET / LINK_RA / MEM_READ / MEM_WRITE (memory fused in);
//   WB interprets REG_WRITE and consumes the JMP->FETCH retirement marker.
//
// The vertical ROM is µword-identical in structure to the sequential
// model's ROM; the per-stage interpreters below decide who executes what.
//
// Defines:
//   VerticalMicrocode::build()   — fills the vertical ROM
//   CPU4V::step_cycle()          — one clock edge of the pipelined machine
//   CPU4V::step_micro() / step() / snapshots

#include "risc201/cpu4.hpp"
#include <sstream>
#include <iomanip>
#include <cstdio>

namespace risc201 {

// =====================================================================
// ROM builder — routine layout identical to the sequential model.
// =====================================================================

static inline VMicroOp M(uint8_t action, uint8_t a1 = 0, uint8_t a2 = 0, uint8_t cond = 0) {
    return VMicroOp{action, a1, a2, cond};
}

static constexpr uint8_t V_ENTRY_FETCH   = 0;
static constexpr uint8_t V_ENTRY_DECODE  = 2;
static constexpr uint8_t V_ENTRY_HALT    = 250;

void VerticalMicrocode::build() {
    for (auto& m : rom) m = M((uint8_t)VAction::NOP);
    for (auto& d : dispatch) d = V_ENTRY_HALT;

    rom[V_ENTRY_FETCH]    = M((uint8_t)VAction::FETCH_IR);
    rom[V_ENTRY_FETCH+1] = M((uint8_t)VAction::JMP_MICRO, 0, V_ENTRY_DECODE);
    rom[V_ENTRY_DECODE]  = M((uint8_t)VAction::DECODE);

    auto emit_routine = [&](uint8_t opcode, std::vector<VMicroOp> body) {
        uint8_t entry = (uint8_t)(16 + opcode * 4);
        size_t i = 0;
        for (; i < body.size() && i < 3; ++i)
            rom[entry + i] = body[i];
        rom[entry + i] = M((uint8_t)VAction::JMP_MICRO, 0, V_ENTRY_FETCH);
        dispatch[opcode] = entry;
    };

    emit_routine(OP_NOP, {});

    auto alu_r = [&](Opcode op) {
        emit_routine(op, {
            M((uint8_t)VAction::OF_READ),
            M((uint8_t)VAction::ALU_OP, (uint8_t)op),
            M((uint8_t)VAction::REG_WRITE),
        });
    };
    alu_r(OP_ADD); alu_r(OP_SUB); alu_r(OP_MUL); alu_r(OP_DIV); alu_r(OP_MOD);
    alu_r(OP_AND); alu_r(OP_OR);
    alu_r(OP_LSL); alu_r(OP_LSR); alu_r(OP_ASR);

    emit_routine(OP_CMP, {
        M((uint8_t)VAction::OF_READ),
        M((uint8_t)VAction::ALU_OP, (uint8_t)OP_CMP),
        M((uint8_t)VAction::SET_FLAGS),
    });

    emit_routine(OP_MOV, {
        M((uint8_t)VAction::OF_READ),
        M((uint8_t)VAction::ALU_OP, (uint8_t)OP_MOV),
        M((uint8_t)VAction::REG_WRITE),
    });
    emit_routine(OP_NOT, {
        M((uint8_t)VAction::OF_READ),
        M((uint8_t)VAction::ALU_OP, (uint8_t)OP_NOT),
        M((uint8_t)VAction::REG_WRITE),
    });

    emit_routine(OP_LD, {
        M((uint8_t)VAction::OF_READ),
        M((uint8_t)VAction::MEM_READ),
        M((uint8_t)VAction::REG_WRITE),
    });

    emit_routine(OP_ST, {
        M((uint8_t)VAction::OF_READ),
        M((uint8_t)VAction::MEM_WRITE),
    });

    emit_routine(OP_B, {
        M((uint8_t)VAction::COMPUTE_TARGET),
        M((uint8_t)VAction::PC_LOAD_TARGET),
    });

    emit_routine(OP_BEQ, {
        M((uint8_t)VAction::COMPUTE_TARGET),
        M((uint8_t)VAction::COND_BRANCH, 0, 0, VC_E),
    });

    emit_routine(OP_BGT, {
        M((uint8_t)VAction::COMPUTE_TARGET),
        M((uint8_t)VAction::COND_BRANCH, 0, 0, VC_GT),
    });

    emit_routine(OP_CALL, {
        M((uint8_t)VAction::LINK_RA),
        M((uint8_t)VAction::COMPUTE_TARGET),
        M((uint8_t)VAction::PC_LOAD_TARGET),
    });

    emit_routine(OP_RET, {
        M((uint8_t)VAction::PC_LOAD_TARGET),
    });

    rom[V_ENTRY_HALT]   = M((uint8_t)VAction::HALT);
    rom[V_ENTRY_HALT+1] = M((uint8_t)VAction::NOP);
    rom[V_ENTRY_HALT+2] = M((uint8_t)VAction::JMP_MICRO, 0, V_ENTRY_HALT);
}

// =====================================================================
// Forwarding network
// =====================================================================

// Does this packet read `reg` as a source GPR?
static bool pkt_reads_reg(const PipePkt& p, uint8_t reg) {
    switch (p.op) {
        case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD:
        case OP_CMP: case OP_AND: case OP_OR:
        case OP_LSL: case OP_LSR: case OP_ASR:
            return p.rs1 == reg || (!p.is_imm && p.rs2 == reg);
        case OP_MOV: case OP_NOT:
            return !p.is_imm && p.rs2 == reg;
        case OP_LD:
            return p.rs1 == reg;
        case OP_ST:
            return p.rs1 == reg || p.rd == reg;
        default:
            return false;
    }
}

// ID-stage bypass. Priority = youngest producer first:
//   EX same-cycle result (ALU or load data) > EX/WB result
//   > regfile (WB already wrote this cycle).
// Because OF is fused into ID and EX produces load data in the SAME cycle
// the dependent instruction decodes, even load-use hazards are bypassed —
// the 4-stage needs NO interlock at all.
uint32_t CPU4V::fwd_id(uint8_t reg, uint32_t rf_val) {
    if (ex_fwd_valid && ex_fwd_rd == reg) { bypass_hits++; return ex_fwd_val; }
    if (ex_wb.valid && ex_wb.result_ready && ex_wb.writes_back && ex_wb.rd == reg) {
        bypass_hits++; return ex_wb.result;
    }
    return rf_val;
}

// =====================================================================
// Per-stage microcode interpreters
// =====================================================================

// WB: interpret REG_WRITE; JMP->FETCH = retire.
int CPU4V::wb_step(RiscException& ex) {
    if (!ex_wb.valid) return 0;
    for (int guard = 0; guard < 8; ++guard) {
        const VMicroOp& m = vuc.rom[ex_wb.upc];
        VAction a = (VAction)m.action;
        if (a == VAction::JMP_MICRO) {
            uint16_t tgt = (uint16_t)((m.arg1 << 8) | m.arg2);
            if (tgt == V_ENTRY_FETCH) {
                wb_retire = ex_wb;
                ex_wb = PipePkt{};
                inst_retired++;
                return 2;
            }
            ex_wb.upc = (uint8_t)tgt;
            continue;
        }
        if (upc_is_wb_local(a)) {
            const InstrInfo* info = info_by_opcode(ex_wb.op);
            if (info && info->writes_reg)
                rf.write(ex_wb.rd, ex_wb.result);
            if (ex_wb.rd == SP_REG && rf.sp() < STACK_LIMIT) {
                char buf[96];
                std::snprintf(buf, sizeof(buf),
                    "SP=0x%08x crossed stack floor (LIMIT=0x%08x)",
                    rf.sp(), STACK_LIMIT);
                ex = { ExKind::StackOverflow, ex_wb.pc, buf };
                return 1;
            }
            ex_wb.upc++;
            continue;
        }
        return 0;
    }
    return 0;
}

// EX: compute / resolve / memory — may interpret several µops of the same
// instruction in one clock (each still a separate vertical µword).
void CPU4V::ex_step(RiscException& ex) {
    ex_fwd_valid = false;
    if (!id_ex.valid) { ex_wb = PipePkt{}; return; }
    PipePkt p = id_ex;
    bool produced = false;
    bool redirect = false;
    for (int guard = 0; guard < 8; ++guard) {
        const VMicroOp& m = vuc.rom[p.upc];
        VAction a = (VAction)m.action;
        if (a == VAction::JMP_MICRO) break;             // retire marker: handled in WB
        int ord = upc_stage_order(a);
        if (ord == 2) {                                 // EX-local µop
            switch (a) {
                case VAction::ALU_OP: {
                    Opcode opcode = (Opcode)m.arg1;
                    alu_out = alu_execute(opcode, p.A, p.B);
                    if (alu_out.exception == 1) {
                        flushed_insts += (if_id.valid ? 1 : 0);
                        if_id = PipePkt{};
                        id_ex = PipePkt{};
                        ex = { ExKind::DivByZero, p.pc, "Division by zero in EX (Goldschmidt)" };
                        halted = true;
                        return;
                    }
                    p.result = alu_out.value; p.result_ready = true;
                    produced = true;
                    break;
                }
                case VAction::SET_FLAGS:
                    rf.flags = alu_out.flags;           // early commit
                    break;
                case VAction::MEM_READ: {
                    uint32_t addr = p.A + (uint32_t)p.imm;
                    mar = addr; mdr = mem.read_word(addr);
                    p.result = mdr; p.result_ready = true;
                    produced = true;
                    break;
                }
                case VAction::MEM_WRITE: {
                    uint32_t addr = p.A + (uint32_t)p.imm;
                    mar = addr; mdr = p.op2;
                    mem.write_word(addr, p.op2);
                    break;
                }
                case VAction::COMPUTE_TARGET:
                    mdr = p.pc + (uint32_t)(p.offset * 4);
                    break;
                case VAction::PC_LOAD_TARGET:
                    rf.pc = (p.op == OP_RET) ? rf.ra() : mdr;
                    redirect = true;
                    break;
                case VAction::LINK_RA:
                    rf.ra() = p.pc + 4;                 // early commit
                    break;
                case VAction::COND_BRANCH: {
                    VCond c = (VCond)m.cond;
                    if (eval_vcond(c, rf.flags)) { rf.pc = mdr; redirect = true; }
                    break;
                }
                default: break;
            }
            p.upc++;
            continue;
        }
        if (ord >= 0 && ord < 2) { p.upc++; continue; } // consumed upstream: skip
        break;
    }
    // Same-cycle result channel for this cycle's ID read (youngest producer).
    if (produced && p.writes_back) {
        ex_fwd_valid = true; ex_fwd_rd = p.rd; ex_fwd_val = p.result;
    }
    if (redirect) {
        flush_pending = true;
        redirect_target = rf.pc;
        redirect_count++; flush_events++;
        stream_end = false;   // redirect resumes the stream (loop back-edge)
    }
    ex_wb = p; ex_wb.valid = true;                     // advance (WB freed by WB)
    id_ex = PipePkt{};
}

// ID: interpret DECODE then OF_READ (fused) — dispatch µPC, read the
// register file through the bypass network, capture A/B/op2.
void CPU4V::id_step() {
    if (!if_id.valid) { id_ex = PipePkt{}; return; }
    PipePkt p = if_id;
    for (int guard = 0; guard < 8; ++guard) {
        const VMicroOp& m = vuc.rom[p.upc];
        VAction a = (VAction)m.action;
        if (a == VAction::JMP_MICRO) {
            p.upc = (uint8_t)((m.arg1 << 8) | m.arg2);  // glue: FETCH -> DECODE
            continue;
        }
        int ord = upc_stage_order(a);
        if (ord == 1) {                                 // ID-local µop
            if (a == VAction::DECODE) {
                Decoded d = decode(p.inst_word);
                p.op = d.op; p.rd = d.rd; p.rs1 = d.rs1; p.rs2 = d.rs2;
                p.imm = d.imm; p.mod = d.mod; p.is_imm = d.is_immediate;
                p.offset = d.offset;
                const InstrInfo* info = info_by_opcode(p.op);
                p.writes_back = (info && info->writes_reg);
                p.is_load  = (p.op == OP_LD);
                p.is_store = (p.op == OP_ST);
                p.upc = vuc.dispatch[(uint8_t)p.op];    // µPC <- dispatch_table[opcode]
                continue;                               // next: OF_READ (also ID-local)
            }
            if (a == VAction::OF_READ) {
                p.A   = fwd_id(p.rs1, rf.read(p.rs1));
                if (p.is_imm) p.B = (uint32_t)p.imm;
                else          p.B = fwd_id(p.rs2, rf.read(p.rs2));
                p.op2 = (p.op == OP_ST) ? fwd_id(p.rd, rf.read(p.rd)) : p.B;
            }
            p.upc++;
            continue;
        }
        if (ord >= 0 && ord < 1) { p.upc++; continue; } // consumed upstream: skip FETCH_IR
        break;                                          // EX µword or retire marker: stop
    }
    id_ex = p; id_ex.valid = true;                     // advance (EX freed by EX)
    if_id = PipePkt{};
}

// IF: interpret FETCH_IR — read MEM[fetch_pc], form the packet, PC += 4.
void CPU4V::if_step(uint32_t fetch_pc) {
    if (stream_end) return;
    uint32_t w = mem.read_word(fetch_pc);
    if (w == 0 && fetch_pc > 0 && !flush_pending) {
        stream_end = true;
        return;
    }
    if_id = PipePkt{};
    if_id.inst_word  = w;
    if_id.pc         = fetch_pc;
    if_id.valid      = true;
    if_id.upc        = V_ENTRY_FETCH;
    if_id.fetch_cycle= cycle;
    if (!flush_pending) rf.pc = fetch_pc + 4;          // PC mux: redirect wins over +4
}

// =====================================================================
// Clock edge orchestrator: WB -> EX -> ID -> IF, then flush.
// Late-to-early order makes same-cycle bypassing possible.
// =====================================================================

RiscException CPU4V::step_cycle() {
    if (halted) return { ExKind::Halt, rf.pc, "halted" };
    RiscException ex{};

    // Drain-complete check: stream over and nothing left in flight.
    if (stream_end && !if_id.valid && !id_ex.valid && !ex_wb.valid) {
        halted = true;
        return { ExKind::Halt, rf.pc, "End of program (zero word)" };
    }

    uint32_t fetch_pc = rf.pc;          // IF's address latch for this cycle

    // 0. Apply pending flush from last cycle's EX redirect (squash younger).
    if (flush_pending) {
        flushed_insts += (if_id.valid ? 1 : 0) + (id_ex.valid ? 1 : 0);
        if_id = PipePkt{}; id_ex = PipePkt{};
        flush_pending = false;
    }

    // 1. WB
    wb_step(ex);
    if (ex.kind == ExKind::StackOverflow) {
        flushed_insts += (id_ex.valid ? 1 : 0) + (if_id.valid ? 1 : 0);
        id_ex = PipePkt{}; if_id = PipePkt{};
        halted = true;
        return ex;
    }

    // 2. EX
    ex_step(ex);
    if (ex.kind != ExKind::None) return ex;             // DivByZero (already halted)

    // 3. ID   4. IF
    id_step();
    if_step(fetch_pc);

    count_in_flight();
    cycle++;
    return ex;
}

void CPU4V::count_in_flight() {
    uint64_t n = (if_id.valid ? 1 : 0) + (id_ex.valid ? 1 : 0) + (ex_wb.valid ? 1 : 0);
    if (n > max_in_flight) max_in_flight = n;
}

RiscException CPU4V::step_micro() { return step_cycle(); }

RiscException CPU4V::step() {
    if (halted) return { ExKind::Halt, rf.pc, "halted" };
    uint64_t start_retired = inst_retired;
    RiscException ex{};
    while (inst_retired == start_retired && !halted) {
        ex = step_cycle();
        if (ex.kind != ExKind::None) return ex;
    }
    return ex;
}

uint8_t CPU4V::current_upc() const {
    if (ex_wb.valid)  return ex_wb.upc;
    if (id_ex.valid)  return id_ex.upc;
    if (if_id.valid)  return if_id.upc;
    return 0;
}

// =====================================================================
// Snapshots
// =====================================================================

static std::string pkt_stage_text(const PipePkt& p) {
    if (!p.valid) return std::string("(bubble)");
    char buf[160];
    std::string mnem = opcode_mnemonic(p.op);
    std::snprintf(buf, sizeof(buf), "pc=0x%04x %-5s µPC=%-3d",
                  p.pc, mnem.c_str(), (int)p.upc);
    return std::string(buf);
}

std::string CPU4V::pipeline_snapshot() const {
    std::ostringstream os;
    os << "Pipeline (4-stage, OPERATIONAL, vertical µcode)  cycle=" << cycle
       << "  retired=" << inst_retired << "\n";
    auto ifline = [&]() {
        if (!if_id.valid) return std::string("(idle)");
        char b[96];
        std::snprintf(b, sizeof(b), "pc=0x%04x word=0x%08x µPC=%d",
                      if_id.pc, if_id.inst_word, (int)if_id.upc);
        return std::string(b);
    };
    os << "  IF : " << ifline() << "\n";
    os << "  ID : " << pkt_stage_text(id_ex) << "\n";
    os << "  EX : " << pkt_stage_text(ex_wb) << "\n";
    os << "  WB : " << pkt_stage_text(wb_retire) << "\n";
    char mline[160];
    std::snprintf(mline, sizeof(mline),
        "  MAR=0x%06x  MDR=0x%08x  ALU=0x%08x  flags: E=%d GT=%d\n",
        mar, mdr, alu_out.value, (int)rf.flags.E, (int)rf.flags.GT);
    os << mline;
    os << "  in-flight=" << ((if_id.valid?1:0)+(id_ex.valid?1:0)+(ex_wb.valid?1:0))
       << " (max " << max_in_flight << ")"
       << "  redirects=" << redirect_count
       << "  flushed=" << flushed_insts
       << "  bypasses=" << bypass_hits << "\n";
    return os.str();
}

std::string CPU4V::regfile_snapshot() const {
    std::ostringstream os;
    os << "---- Registers / Flags / PC ----\n";
    for (int i = 0; i < REG_COUNT; ++i) {
        char buf[64];
        std::snprintf(buf, sizeof(buf), "%4s=0x%08x  ",
                      register_name(i).c_str(), rf.r[i]);
        os << buf;
        if ((i & 3) == 3) os << "\n";
    }
    char pc[64];
    std::snprintf(pc, sizeof(pc), "PC  =0x%08x\n", rf.pc);
    os << pc;
    os << "flags: E=" << (int)rf.flags.E << " GT=" << (int)rf.flags.GT
       << "  µPC=" << (int)current_upc() << "\n";
    return os.str();
}

std::string CPU4V::micro_snapshot() const {
    std::ostringstream os;
    os << "Microcode sequencers (vertical, one µPC per in-flight packet):\n";
    auto line = [&](const char* stage, const PipePkt& p) {
        if (!p.valid) {
            char b[96]; std::snprintf(b, sizeof(b), "  %-5s (no packet)\n", stage);
            os << b; return;
        }
        const VMicroOp& m = vuc.rom[p.upc];
        char b[176];
        std::snprintf(b, sizeof(b),
            "  %-5s pc=0x%04x µPC=%-3d µword: %s (arg1=%d arg2=%d cond=%d)\n",
            stage, p.pc, (int)p.upc, vaction_name((VAction)m.action),
            (int)m.arg1, (int)m.arg2, (int)m.cond);
        os << b;
    };
    line("IF/ID", if_id);
    line("ID/EX", id_ex);
    line("EX/WB", ex_wb);
    os << "  ROM: " << VROM_SIZE << " µwords, 32-bit vertical (1 action/µop)"
       << "; dispatch[opcode] -> 16 + opcode*4\n";
    return os.str();
}

} // namespace risc201
