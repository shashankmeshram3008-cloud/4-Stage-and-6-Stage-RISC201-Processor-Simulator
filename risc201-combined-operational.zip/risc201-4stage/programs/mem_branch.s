@ mem_branch.s — memory + branch demo: sum of 8 integers
@ Compute sum of 8 integers stored at `array`. Result in r3.
@ r5 = 4 (byte stride), r6 = 1.

mov r1, array       @ r1 = address of array
mov r2, 8           @ r2 = count
mov r3, 0           @ r3 = accumulator
mov r5, 4           @ r5 = 4 (byte stride)
mov r6, 1           @ r6 = 1

.loop:
cmp r2, r6          @ count == 1? (last element)
beq .last           @ handle last element
ld r4, 0[r1]        @ r4 = MEM[R1]
add r3, r3, r4      @ accumulator += r4
add r1, r1, r5      @ advance pointer by 4 bytes
sub r2, r2, r6      @ count--
b .loop

.last:
ld r4, 0[r1]        @ load last element
add r3, r3, r4      @ accumulator += r4
b .end

array:
.word 1, 2, 3, 4, 5, 6, 7, 8
.end:
