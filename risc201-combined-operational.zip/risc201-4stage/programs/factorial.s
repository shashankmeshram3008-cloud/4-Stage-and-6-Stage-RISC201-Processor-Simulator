@ =====================================================================
@ factorial.s - iterative factorial of N (in r0), result in r1
@ Risc201 (Sarangi) - Example 29
@ Compute N! for N = 6 -> 720 in r1.
mov r0, 6          @ N = 6
mov r1, 1          @ prod = 1
mov r2, r0         @ idx = N
.loop:
mul r1, r1, r2     @ prod = prod * idx
sub r2, r2, 1      @ idx = idx - 1
cmp r2, 1          @ compare idx with 1
bgt .loop          @ if idx > 1, keep looping
@ r1 holds N!
