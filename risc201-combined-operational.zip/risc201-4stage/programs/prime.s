@ =====================================================================
@ prime.s - test if the number in r1 is prime; result (0/1) in r0
@ Risc201 (Sarangi) - Example 30
@ r1 = 29 (prime) -> r0 = 1
mov r1, 29
mov r2, 2          @ divisor starts at 2
.loop:
mod r3, r1, r2     @ r3 = r1 mod r2
cmp r3, 0          @ divisible?
beq .notprime      @ yes -> not prime
add r2, r2, 1      @ r2++
cmp r1, r2         @ compare r2 with r1
bgt .loop          @ if r2 < r1, keep testing
mov r0, 1          @ prime
b .exit
.notprime:
mov r0, 0          @ not prime
.exit:
