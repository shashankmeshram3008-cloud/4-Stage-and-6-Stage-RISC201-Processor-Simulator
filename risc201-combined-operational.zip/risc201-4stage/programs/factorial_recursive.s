@ factorial_recursive.s — recursive factorial(5) = 120
@ Uses full-descending stack with manual ENTER/LEAVE.
@ Convention: r0=return value, r1=n, r5=1, r12=FP, r15=RA, r14=SP.

mov r1, 5           @ n = 5
mov r5, 1           @ constant 1
call .fact
b .end

.fact:
@ ENTER: push RA, push FP(r12), FP = SP
sub sp, sp, 4       @ push ra
st ra, 0[sp]
sub sp, sp, 4       @ push fp (r12)
st r12, 0[sp]
mov r12, sp         @ fp = sp

cmp r1, r5          @ n <= 1?
bgt .recurse        @ n > 1 → recurse
mov r0, 1           @ base case: fact(1) = 1
b .fact_return

.recurse:
sub sp, sp, 4       @ push n (r1)
st r1, 0[sp]
sub r1, r1, r5      @ n = n - 1
call .fact          @ recursive call
ld r1, 0[sp]        @ restore n
add sp, sp, 4       @ pop n
mul r0, r0, r1      @ r0 = fact(n-1) * n

.fact_return:
@ LEAVE: SP = FP, pop FP, pop RA
mov sp, r12         @ sp = fp
ld r12, 0[sp]       @ pop fp
add sp, sp, 4
ld ra, 0[sp]        @ pop ra
add sp, sp, 4
ret

.end:
