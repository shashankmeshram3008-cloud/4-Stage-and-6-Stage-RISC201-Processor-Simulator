@ bubble_sort.s — sort 8 integers in ascending order using bubble sort.
@ Demonstrates ld/st, nested loops, conditional swap.
@ After running, the array at `arr` is sorted in place: [1,2,3,4,5,7,8,9].
@ r0 = zero constant, r5 = 4 (byte stride), r6 = 1 (constant).

mov r0, 0           @ r0 = 0 (zero constant)
mov r5, 4           @ r5 = 4 (byte stride per array element)
mov r6, 1           @ r6 = 1
mov r1, arr         @ r1 = &arr[0]
mov r2, 8           @ r2 = N = 8

.outer:
mov r3, 0           @ r3 = swapped flag (0 = no swap)
mov r4, 0           @ r4 = j (byte offset, 0..(N-1)*4)
sub r7, r2, r6      @ r7 = N - 1
mul r7, r7, r5      @ r7 = (N-1)*4 = byte limit for j

.inner:
cmp r4, r7          @ compare j with limit
bgt .inner_done     @ j > limit → done
beq .inner_done     @ j == limit → done
add r8, r1, r4      @ r8 = &arr[j]
ld r9, 0[r8]        @ r9 = arr[j]
ld r10, 4[r8]       @ r10 = arr[j+1]
cmp r9, r10
bgt .do_swap        @ arr[j] > arr[j+1] → swap
b .no_swap
.do_swap:
st r10, 0[r8]       @ arr[j] = old arr[j+1]
st r9, 4[r8]        @ arr[j+1] = old arr[j]
mov r3, 1           @ mark swapped
.no_swap:
add r4, r4, r5      @ j += 4 (next element)
b .inner

.inner_done:
cmp r3, r0          @ swapped == 0?
beq .done           @ no swaps → sorted
b .outer

.done:
b .end

arr:
.word 5, 2, 8, 1, 9, 3, 7, 4
.end:
