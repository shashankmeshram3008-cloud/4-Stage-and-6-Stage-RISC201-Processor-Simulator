@ sum_1_to_100.s — sum integers 1..100 = 5050
@ Result in r0.

mov r0, 0           @ sum = 0
mov r1, 1           @ i = 1
mov r2, 100         @ n = 100
mov r5, 1           @ constant 1

.loop:
cmp r1, r2          @ i > 100?
bgt .done
add r0, r0, r1      @ sum += i
add r1, r1, r5      @ i++
b .loop

.done:
