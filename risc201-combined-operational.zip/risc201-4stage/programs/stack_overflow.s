@ stack_overflow.s — deliberately trigger stack overflow.
@ Recurses without a base case, pushing onto the stack each call,
@ until SP crosses STACK_LIMIT. The CPU should raise a StackOverflow.

mov r1, 1           @ n = 1
mov r5, 1           @ constant 1
call .recurse
b .end

.recurse:
@ ENTER: push RA, push FP, FP = SP
sub sp, sp, 4
st ra, 0[sp]
sub sp, sp, 4
st r12, 0[sp]
mov r12, sp

sub r1, r1, r5      @ n-- (just to do something)
call .recurse       @ infinite recursion — never returns

@ LEAVE (never reached, but included for completeness)
mov sp, r12
ld r12, 0[sp]
add sp, sp, 4
ld ra, 0[sp]
add sp, sp, 4
ret

.end:
