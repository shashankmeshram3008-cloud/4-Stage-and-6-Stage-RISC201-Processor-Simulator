@ =====================================================================
@ gcd.s - greatest common divisor of two numbers (Euclid's algorithm)
@ Inputs: r0 = a, r1 = b.  Output: r2 = gcd(a, b)
@ gcd(48, 36) = 12
mov r0, 48
mov r1, 36
.loop:
cmp r1, 0          @ while b != 0
beq .done
mod r2, r0, r1     @ r2 = a mod b
mov r0, r1         @ a = b
mov r1, r2         @ b = a mod b
b .loop
.done:
@ r0 holds gcd(a, b); copy to r2 for a single result location
mov r2, r0
