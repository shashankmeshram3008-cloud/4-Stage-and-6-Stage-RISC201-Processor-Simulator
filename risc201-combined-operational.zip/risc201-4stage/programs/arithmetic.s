@ =====================================================================
@ arithmetic.s - exercise all ALU operations (CLA, Booth, Goldschmidt)
@ Tests add/sub/mul/div/mod/and/or/shifts with bitwise algorithms.
mov r0, 100
mov r1, 7
add r2, r0, r1     @ 107 (CLA)
sub r3, r0, r1     @ 93  (CLA)
mul r4, r0, r1     @ 700 (Booth)
div r5, r0, r1     @ 14  (Goldschmidt)
mod r6, r0, r1     @ 2   (Goldschmidt)
and r7, r0, r1     @ 4   (bitwise)
or  r8, r0, r1     @ 103 (bitwise)
lsl r9, r1, 2      @ 28  (shift)
lsr r10, r0, 2     @ 25  (shift)
asr r11, r0, 2     @ 25  (arithmetic shift)
