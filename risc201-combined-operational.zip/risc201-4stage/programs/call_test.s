@ =====================================================================
@ call_test.s - test call/ret (function call and return)
@ Calls a function that adds r0 + r1, result in r2.
mov r0, 3
mov r1, 4
call .add
b .end
.add:
add r2, r0, r1
ret
.end:
