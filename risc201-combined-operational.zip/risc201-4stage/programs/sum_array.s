@ =====================================================================
@ sum_array.s - sum of an integer array, result in r0
@ Risc201 (Sarangi) - demonstrates ld and loops
@ Array of 5 integers: 5, 10, 15, 20, 25 -> sum = 75 in r0
mov r0, 0          @ sum
mov r1, 0          @ byte index
mov r2, 20         @ total bytes (5 elements x 4 bytes)
.loop:
cmp r1, r2
beq .done
ld r3, array[r1]   @ load array[index]
add r0, r0, r3
add r1, r1, 4      @ index += 4 bytes
b .loop
.done:
b .end
array:
.word 5, 10, 15, 20, 25
.end:
