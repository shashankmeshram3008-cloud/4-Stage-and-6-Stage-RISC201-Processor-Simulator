@ factorial_iterative.s — compute 5! = 120 iteratively
@ Result in r0. r10 = zero constant.

mov r10, 0          @ r10 = 0 (zero constant)
mov r1, 5           @ n = 5
mov r0, 1           @ result = 1
mov r5, 1           @ constant 1

.loop:
cmp r1, r10         @ n == 0?
beq .done
mul r0, r0, r1      @ result *= n
sub r1, r1, r5      @ n--
b .loop

.done:
