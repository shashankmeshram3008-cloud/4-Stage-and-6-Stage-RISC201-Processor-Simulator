@ stack_call.s — recursive factorial(5) = 120 using full-descending stack.
@ Convention: r0=return value, r1=n, r5=1, r12=FP, r15=RA, r14=SP.

mov r1, 5           @ n = 5
mov r5, 1           @ constant 1
call .fact
b .end

.fact:
@ ENTER: push RA, push FP, FP = SP
sub sp, sp, 4
st ra, 0[sp]
sub sp, sp, 4
st r12, 0[sp]
mov r12, sp

cmp r1, r5          @ n <= 1?
bgt .recurse
mov r0, 1           @ base case: fact(1) = 1
b .fact_ret

.recurse:
sub sp, sp, 4       @ push n
st r1, 0[sp]
sub r1, r1, r5      @ n = n - 1
call .fact
ld r1, 0[sp]        @ restore n
add sp, sp, 4
mul r0, r0, r1      @ r0 = fact(n-1) * n

.fact_ret:
@ LEAVE: SP = FP, pop FP, pop RA
mov sp, r12
ld r12, 0[sp]
add sp, sp, 4
ld ra, 0[sp]
add sp, sp, 4
ret

.end:
