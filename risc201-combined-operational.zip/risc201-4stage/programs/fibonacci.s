@ =====================================================================
@ fibonacci.s - compute the Nth Fibonacci number (iterative)
@ Input: r0 = N. Output: r1 = fib(N).
@ fib(10) = 55
mov r0, 10         @ N = 10
mov r1, 0          @ fib(0)
mov r2, 1          @ fib(1)
mov r3, 0          @ counter
.loop:
cmp r3, r0
beq .done
add r4, r1, r2     @ fib(i+1) = fib(i-1) + fib(i)
mov r1, r2         @ shift window
mov r2, r4
add r3, r3, 1      @ i++
b .loop
.done:
@ r1 holds fib(N)
