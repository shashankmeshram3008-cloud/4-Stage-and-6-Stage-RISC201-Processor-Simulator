@ Risc201 test program - computes 31 * 29 - 50, result in r4
@ (Example 26 from Sarangi, Section 3.3.4)
mov r1, 31
mov r2, 29
mul r3, r1, r2
sub r4, r3, 50
