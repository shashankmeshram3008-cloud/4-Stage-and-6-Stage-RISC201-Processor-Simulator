# Risc201 4-stage CPU (vertical microcode, operational pipeline)

A **true overlapping** 4-stage pipeline (IF / ID / EX / WB) driven by a
**vertical microcode** control unit: 32-bit µword, one action per µop,
~4 µops per macro instruction. Operand fetch is fused into ID; memory
access is fused into EX.

| Property | Value |
|----------|-------|
| Pipeline stages | IF / ID / EX / WB |
| Execution model | **Operational, overlapping** (up to 3 instructions in flight) |
| Control unit | Vertical microcode ROM, 32-bit µword, 1 action/µop |
| Per-instruction µPC | Travels with the instruction through the pipeline |
| RAW hazard handling | Full bypass into ID — **zero stalls** (incl. load-use) |
| Branch handling | Resolved in EX; taken branch = 2-bubble squash |
| Clock period (synthetic) | 1.0 ns/cycle (critical path: ALU + memory fused in EX) |
| ROM entries used | 256 |

## Execution model

**This simulator executes instructions in an overlapping pipeline.**
Every clock cycle all four stages interpret their microcode in parallel:

- **IF** interprets `FETCH_IR` (IR ← MEM[PC]; PC ← PC+4) for a **new**
  instruction every cycle.
- **ID** interprets `DECODE` (µPC ← dispatch_table[opcode]) and `OF_READ`
  (A/B/op2 ← regfile, with bypass) for the instruction in IF/ID.
- **EX** interprets `ALU_OP`, `SET_FLAGS`, `COMPUTE_TARGET`, `COND_BRANCH`,
  `PC_LOAD_TARGET`, `LINK_RA`, `MEM_READ`, `MEM_WRITE` for the instruction
  in ID/EX. Branches redirect the PC here; everything younger is squashed.
- **WB** interprets `REG_WRITE` (R[rd] ← result, SP floor check) and
  consumes the `JMP_MICRO → FETCH` marker = **retirement**.

The key mechanism: **each in-flight instruction carries its own µPC in the
pipeline registers.** Each stage walks the µword at that µPC, executes only
the µops statically assigned to it (see `upc_stage_order()` in cpu4.hpp),
skips µops consumed by earlier stages, and stops at µops owned by later
stages. There is **no hardwired control logic anywhere** — every register
write, ALU operation, memory access, PC load, and flag commit happens
because a vertical µword said so.

Steady state: **one instruction retires per cycle** (CPI ≈ 1.25–1.75 on
the test suite; the excess over 1.0 is branch squashes + pipeline fill).

## Hazards

| Hazard | Handling | Cost |
|--------|----------|------|
| RAW (ALU → ALU/ld/st) | Bypass: EX same-cycle result → ID; EX/WB result → ID; regfile write-first | **0 cycles** |
| RAW (ld → any) | Load data is produced in EX the same cycle the consumer decodes → same-cycle bypass | **0 cycles** |
| Flags (cmp → beq/bgt) | `SET_FLAGS` µop commits in EX; branch reads flags in EX ≥ 1 cycle later | **0 cycles** |
| ra (call → ret) | `LINK_RA` µop commits in EX | **0 cycles** |
| Taken branch (b/beq/bgt/call/ret) | PC redirect in EX; IF/ID + ID/EX squashed | **2 bubbles** |
| Not-taken branch | fall-through already fetched | **0 bubbles** |
| Exceptions (DivByZero, StackOverflow) | faulting packet + younger packets squashed | precise |

## Building and running

```bash
make
./risc201-4stage programs/factorial.s                 # run to halt
./risc201-4stage programs/factorial.s --trace         # per-cycle reservation table
./risc201-4stage programs/factorial.s --debug         # interactive REPL
./risc201-4stage programs/factorial.s --listing       # assembler listing
./risc201-4stage programs/factorial.s --disasm        # disassemble
./risc201-4stage programs/factorial.s --hex           # hex words
```

## Benchmark: 4-stage vs 6-stage

Same programs, same ROM, same ISA, and identical retired instruction
streams. `time = cycles × clock_period` (this CPU: 1.0 ns; the 6-stage: 0.77 ns).

| Program             | 4st cyc | 4st CPI | 6st cyc | 6st CPI | cyc ratio 6/4 | time ratio 6/4 |
|---------------------|---------|---------|---------|---------|---------------|----------------|
| arithmetic          | 15      | 1.25    | 17      | 1.42    | 1.13          | 0.87           |
| bubble_sort         | 629     | 1.35    | 746     | 1.60    | 1.19          | 0.91           |
| call_test           | 13      | 2.17    | 17      | 2.83    | 1.31          | 1.01           |
| expr                | 7       | 1.75    | 9       | 2.25    | 1.29          | 0.99           |
| factorial           | 34      | 1.48    | 40      | 1.74    | 1.18          | 0.91           |
| factorial_iterative | 44      | 1.42    | 51      | 1.65    | 1.16          | 0.89           |
| factorial_recursive | 132     | 1.33    | 149     | 1.51    | 1.13          | 0.87           |
| fibonacci           | 99      | 1.30    | 111     | 1.46    | 1.12          | 0.86           |
| gcd                 | 26      | 1.53    | 31      | 1.82    | 1.19          | 0.92           |
| mem_branch          | 78      | 1.32    | 96      | 1.63    | 1.23          | 0.95           |
| prime               | 221     | 1.33    | 249     | 1.50    | 1.13          | 0.87           |
| stack_call          | 132     | 1.33    | 149     | 1.51    | 1.13          | 0.87           |
| stack_overflow      | 36865   | 1.29    | 40963   | 1.43    | 1.11          | 0.86           |
| sum_1_to_100        | 709     | 1.40    | 811     | 1.60    | 1.14          | 0.88           |
| sum_array           | 51      | 1.42    | 64      | 1.78    | 1.25          | 0.97           |

`cyc ratio 6/4` is the 6-stage's cycle count over this CPU's; `time ratio 6/4`
also includes the clock periods, so a value below 1.0 means the 6-stage
finishes sooner. Both CPUs produce identical register-file final states for
all 15 programs (semantic equivalence verified by script).

**Why CPI > 1:** every taken branch squashes the 2 younger in-flight
instructions (2 bubbles), and the pipeline takes 4 cycles to fill and
drains at the end. Straight-line code (arithmetic) runs at CPI 1.25 —
lower than the 6-stage's 1.42 on every program, thanks to the fused ID
and the 2-bubble squash; the 6-stage answers with a 23% shorter clock
period, which wins wall-clock time on 14 of 15 programs.

## Timing model

Synthetic timing model: `time = cycles × clock_period`, clock = 1.0 ns
(critical path = EX doing ALU + memory in series, ≈1050 ps).

## Trace mode (reservation table)

`--trace` prints one line per clock cycle showing the contents of each
pipeline register — the overlap is directly visible:

```
   cyc | IF/ID        | ID/EX        | EX/WB        | WB (retire)
     4 | 0x08 mul     | 0x04 mov     | 0x00 mov     | 0x00 *retired lat=4cyc
     5 | 0x0c sub     | 0x08 mul     | 0x04 mov     | 0x04 *retired lat=4cyc
```

`lat=4cyc` is the instruction's full pipeline latency (fetch → retire);
retirements happen every cycle in steady state.

## Debugger

| Command | Action |
|---------|--------|
| `s`     | run until the next instruction retires (macro step) |
| `m`     | step **one clock cycle** — every stage interprets its µops |
| `r`     | register file + flags |
| `p`     | pipeline snapshot: packet + µPC per stage, MAR/MDR, stats |
| `u`     | per-stage microcode sequencer state (all µPCs + µwords) |
| `d <addr>` / `mem <addr>` / `st` / `cs` | disassemble, memory dump, stack visualiser, stack safety |
| `c <n>` | run up to n macro steps |

## File layout

```
risc201-4stage/
├── include/risc201/
│   ├── isa.hpp           # Risc201 ISA (shared)
│   ├── alu.hpp           # CLA + Booth + Goldschmidt (shared)
│   ├── core.hpp          # regfile, memory, stack (shared)
│   ├── cpu4.hpp          # CPU4V — packet, stage µop map, bypass network
│   ├── assembler.hpp     # shared two-pass assembler
│   └── debugger.hpp      # trace logger + REPL (pipeline-aware)
├── src/
│   ├── cpu4.cpp          # ROM builder + per-stage interpreters + step_cycle
│   └── main.cpp          # CLI entry (adds CPI/redirect stats)
├── programs/             # 15 .s test programs (identical in both projects)
└── Makefile
```

## Design highlights

- **No hardwired logic anywhere.** Every control signal flows from the
  vertical control-store ROM through the per-stage microcode interpreters.
- **Per-instruction µPC** travels in the pipeline registers — the pipeline
  is a set of five concurrent microcode sequencers (one per stage).
- **Bitwise ALU** (shared): Carry-Lookahead Adder, Booth
  radix-2 multiplier, Goldschmidt division.
- **Stack-overflow detection at writeback time:** any write to
  `sp` below `STACK_LIMIT = 0x8000` raises `StackOverflow`; younger
  in-flight packets are squashed precisely.
- **PC-redirect µops live in EX** so that squashed instructions have not
  yet committed any architectural state (registers, memory, flags, ra).

## Risc201 ISA quick reference

- **16 registers** `r0..r15` (32-bit). `r14 = sp`, `r15 = ra`.
  Internal **flags**: `E` (equal), `GT` (greater-than), written only by `cmp`.
- **32-bit fixed-width instructions**, 3 encoding formats:
  branch `op(5)|offset(27)`; register `op(5)|I=0|rd(4)|rs1(4)|rs2(4)`;
  immediate `op(5)|I=1|rd(4)|rs1(4)|imm(18)`.
- **21 opcodes**: `add sub mul div mod cmp and or not mov lsl lsr asr nop
  ld st beq bgt b call ret`.
- **Immediate modifiers** (`u`/`h` suffix): sign-extend / zero-extend /
  upper-16.
