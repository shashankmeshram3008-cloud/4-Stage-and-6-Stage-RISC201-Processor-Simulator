# Risc201 6-stage CPU (vertical microcode, operational pipeline)

A **true overlapping** 6-stage pipeline (IF / ID / OF / EX / MA / WB)
driven by a **vertical microcode** control unit: 32-bit µword, one action
per µop, ~5 µops per macro instruction.

| Property | Value |
|----------|-------|
| Pipeline stages | IF / ID / OF / EX / MA / WB |
| Execution model | **Operational, overlapping** (up to 5 instructions in flight) |
| Control unit | Vertical microcode ROM, 32-bit µword, 1 action/µop |
| Per-instruction µPC | Travels with the instruction through the pipeline |
| RAW hazard handling | Full bypass into OF + 1-cycle load-use interlock |
| Branch handling | Resolved in EX; taken branch = 3-bubble squash |
| Clock period (synthetic) | 0.77 ns/cycle (critical path: max(t_ALU, t_memory) ≈ 700 ps) |
| ROM entries used | 256 |

## Execution model

**This simulator executes instructions in an overlapping pipeline.**
Every clock cycle all six stages interpret their microcode in parallel:

- **IF** interprets `FETCH_IR` (IR ← MEM[PC]; PC ← PC+4) for a **new**
  instruction every cycle.
- **ID** interprets `DECODE` (µPC ← dispatch_table[opcode]) for the
  instruction in IF/ID.
- **OF** interprets `OF_READ` (A/B/op2 ← regfile, with bypass) for the
  instruction in ID/OF. Branches pass straight through (no OF µword).
- **EX** interprets `ALU_OP`, `SET_FLAGS`, `COMPUTE_TARGET`, `COND_BRANCH`,
  `PC_LOAD_TARGET`, `LINK_RA` for the instruction in OF/EX. Branches
  redirect the PC here; everything younger is squashed.
- **MA** interprets `MEM_READ` (MAR ← A+imm; MDR ← MEM[MAR]) and
  `MEM_WRITE` (MEM[MAR] ← op2) for the instruction in EX/MA.
- **WB** interprets `REG_WRITE` (R[rd] ← result, SP floor check) and
  consumes the `JMP_MICRO → FETCH` marker = **retirement**.

The key mechanism: **each in-flight instruction carries its own µPC in the
pipeline registers.** Each stage walks the µword at that µPC, executes only
the µops statically assigned to it (see `upc_stage_order()` in cpu6.hpp),
skips µops consumed by earlier stages, and stops at µops owned by later
stages. There is **no hardwired control logic anywhere** — every register
write, ALU operation, memory access, PC load, and flag commit happens
because a vertical µword said so.

Steady state: **one instruction retires per cycle** (CPI ≈ 1.4–1.8 on the
test suite; the excess over 1.0 is branch squashes, the load-use interlock,
and pipeline fill/drain).

## Hazards

| Hazard | Handling | Cost |
|--------|----------|------|
| RAW (ALU → ALU/ld/st), distance ≥ 1 | Bypass into OF: EX same-cycle result > EX/MA result > MA same-cycle load > MA/WB result > regfile write-first | **0 cycles** |
| RAW (ld → dependent in OF) | Classic load-use interlock: consumer held 1 cycle in OF, then forwarded from MA | **1 bubble** |
| Flags (cmp → beq/bgt) | `SET_FLAGS` µop commits in EX; branch reads flags in EX ≥ 1 cycle later | **0 cycles** |
| ra (call → ret) | `LINK_RA` µop commits in EX | **0 cycles** |
| Taken branch (b/beq/bgt/call/ret) | PC redirect in EX; IF/ID + ID/OF + OF/EX squashed | **3 bubbles** |
| Not-taken branch | fall-through already fetched | **0 bubbles** |
| Exceptions (DivByZero, StackOverflow) | faulting packet + younger packets squashed | precise |

## Building and running

```bash
make
./risc201-6stage programs/factorial.s                 # run to halt
./risc201-6stage programs/factorial.s --trace         # per-cycle reservation table
./risc201-6stage programs/factorial.s --debug         # interactive REPL
./risc201-6stage programs/factorial.s --listing       # assembler listing
./risc201-6stage programs/factorial.s --disasm        # disassemble
./risc201-6stage programs/factorial.s --hex           # hex words
```

## Benchmark: 4-stage vs 6-stage

Same programs, same ROM, same ISA, and identical retired instruction
streams. `time = cycles × clock_period` (this CPU: 0.77 ns; the 4-stage: 1.0 ns).

| Program             | 4st cyc | 4st CPI | 6st cyc | 6st CPI | cyc ratio 6/4 | time ratio 6/4 |
|---------------------|---------|---------|---------|---------|---------------|----------------|
| arithmetic          | 15      | 1.25    | 17      | 1.42    | 1.13          | 0.87           |
| bubble_sort         | 629     | 1.35    | 746     | 1.60    | 1.19          | 0.91           |
| call_test           | 13      | 2.17    | 17      | 2.83    | 1.31          | 1.01           |
| expr                | 7       | 1.75    | 9       | 2.25    | 1.29          | 0.99           |
| factorial           | 34      | 1.48    | 40      | 1.74    | 1.18          | 0.91           |
| factorial_iterative | 44      | 1.42    | 51      | 1.65    | 1.16          | 0.89           |
| factorial_recursive | 132     | 1.33    | 149     | 1.51    | 1.13          | 0.87           |
| fibonacci           | 99      | 1.30    | 111     | 1.46    | 1.12          | 0.86           |
| gcd                 | 26      | 1.53    | 31      | 1.82    | 1.19          | 0.92           |
| mem_branch          | 78      | 1.32    | 96      | 1.63    | 1.23          | 0.95           |
| prime               | 221     | 1.33    | 249     | 1.50    | 1.13          | 0.87           |
| stack_call          | 132     | 1.33    | 149     | 1.51    | 1.13          | 0.87           |
| stack_overflow      | 36865   | 1.29    | 40963   | 1.43    | 1.11          | 0.86           |
| sum_1_to_100        | 709     | 1.40    | 811     | 1.60    | 1.14          | 0.88           |
| sum_array           | 51      | 1.42    | 64      | 1.78    | 1.25          | 0.97           |

`cyc ratio 6/4` is this CPU's cycle count over the 4-stage's; `time ratio 6/4`
also includes the clock periods, so a value below 1.0 means this CPU
finishes sooner. Both CPUs produce identical register-file final states for
all 15 programs (semantic equivalence verified by script).

**Why CPI > 1:** every taken branch squashes the 3 younger in-flight
instructions (3 bubbles), each `ld` consumed one instruction later costs 1
interlock bubble, and the pipeline takes 6 cycles to fill and drains at the
end. Straight-line ALU code (arithmetic) runs at CPI 1.42 — higher than the
4-stage's 1.25 on every program, the price of the split operand-fetch stage
and the 3-bubble squash; the 23% shorter clock period buys it back, winning
wall-clock time on 14 of 15 programs.

## Timing model

Synthetic timing model: `time = cycles × clock_period`, clock = 0.77 ns
(critical path = max(t_EX ≈ 700 ps ALU, t_MA ≈ 350 ps memory)).

## Trace mode (reservation table)

`--trace` prints one line per clock cycle showing the contents of each
pipeline register — the overlap is directly visible:

```
   cyc | IF/ID        | ID/OF        | OF/EX        | EX/MA        | MA/WB        | WB (retire)
     6 | -            | 0x0c sub     | 0x08 mul     | 0x04 mov     | 0x00 mov     | 0x00 *retired lat=6cyc
     7 | -            | -            | 0x0c sub     | 0x08 mul     | 0x04 mov     | 0x04 *retired lat=6cyc
```

`lat=6cyc` is the instruction's full pipeline latency (fetch → retire);
retirements happen every cycle in steady state.

## Debugger

| Command | Action |
|---------|--------|
| `s`     | run until the next instruction retires (macro step) |
| `m`     | step **one clock cycle** — every stage interprets its µops |
| `r`     | register file + flags |
| `p`     | pipeline snapshot: packet + µPC per stage, MAR/MDR, stats |
| `u`     | per-stage microcode sequencer state (all µPCs + µwords) |
| `d <addr>` / `mem <addr>` / `st` / `cs` | disassemble, memory dump, stack visualiser, stack safety |
| `c <n>` | run up to n macro steps |

## File layout

```
risc201-6stage/
├── include/risc201/
│   ├── isa.hpp           # Risc201 ISA (shared)
│   ├── alu.hpp           # CLA + Booth + Goldschmidt (shared)
│   ├── core.hpp          # regfile, memory, stack (shared)
│   ├── cpu6.hpp          # CPU6V — packet, stage µop map, bypass network
│   ├── assembler.hpp     # shared two-pass assembler
│   └── debugger.hpp      # trace logger + REPL (pipeline-aware)
├── src/
│   ├── cpu6.cpp          # ROM builder + per-stage interpreters + step_cycle
│   └── main.cpp          # CLI entry (adds CPI/redirect stats)
├── programs/             # 15 .s test programs (identical in both projects)
└── Makefile
```

## Design highlights

- **No hardwired logic anywhere.** Every control signal flows from the
  vertical control-store ROM through the per-stage microcode interpreters.
- **Per-instruction µPC** travels in the pipeline registers — the pipeline
  is a set of six concurrent microcode sequencers (one per stage).
- **Bitwise ALU** (shared): Carry-Lookahead Adder, Booth
  radix-2 multiplier, Goldschmidt division.
- **Stack-overflow detection at writeback time:** any write to
  `sp` below `STACK_LIMIT = 0x8000` raises `StackOverflow`; younger
  in-flight packets are squashed precisely.
- **PC-redirect µops live in EX** so that squashed instructions have not
  yet committed any architectural state (registers, memory, flags, ra).

## Risc201 ISA quick reference

- **16 registers** `r0..r15` (32-bit). `r14 = sp`, `r15 = ra`.
  Internal **flags**: `E` (equal), `GT` (greater-than), written only by `cmp`.
- **32-bit fixed-width instructions**, 3 encoding formats:
  branch `op(5)|offset(27)`; register `op(5)|I=0|rd(4)|rs1(4)|rs2(4)`;
  immediate `op(5)|I=1|rd(4)|rs1(4)|imm(18)`.
- **21 opcodes**: `add sub mul div mod cmp and or not mov lsl lsr asr nop
  ld st beq bgt b call ret`.
- **Immediate modifiers** (`u`/`h` suffix): sign-extend / zero-extend /
  upper-16.
