// risc201/debugger.hpp — Interactive CLI debugger + pipelined trace logger.
// Targets CPU6V (OPERATIONAL 6-stage pipeline, vertical microcode) via the
// IDebugTarget interface.

#pragma once

#include "isa.hpp"
#include "core.hpp"
#include "assembler.hpp"
#include "cpu6.hpp"
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdint>
#include <cstdio>
#include <iomanip>

namespace risc201 {

// Abstract debugger target interface — implemented by CPU6V.
struct IDebugTarget {
    virtual ~IDebugTarget() = default;
    virtual RiscException step_one_macro() = 0;   // run until next retirement
    virtual RiscException step_one_micro() = 0;   // one clock cycle (all stages)
    virtual bool is_halted() const = 0;
    virtual RegisterFile const& regs() const = 0;
    virtual Memory const& memory() const = 0;
    virtual Stack const& stack_obj() const = 0;
    virtual std::string pipeline_snapshot() const = 0;
    virtual std::string regfile_snapshot() const = 0;
    virtual std::string micro_snapshot() const = 0;
    virtual uint64_t cycle_count() const = 0;
    virtual uint64_t retired_count() const = 0;
    virtual std::string cpu_name() const = 0;
    virtual uint8_t current_upc() const = 0;
    // Timing model — see CYCLE_PERIOD_PS in cpu6.hpp.
    virtual uint64_t cycle_period_ps() const = 0;
    virtual uint64_t elapsed_time_ps() const = 0;
    // Pipeline observability (pipelined CPUs)
    virtual bool packet_at_stage(int stage, uint32_t& pc, std::string& mnem,
                                 bool& valid) const = 0;
    virtual uint64_t in_flight_now() const = 0;
    virtual uint64_t max_in_flight() const = 0;
    virtual uint64_t redirect_count() const = 0;
    virtual uint64_t flushed_count() const = 0;
    virtual uint64_t bypass_count() const = 0;
    virtual uint64_t fetch_cycle_of_last_retired() const = 0;
    virtual uint32_t last_retired_pc() const = 0;
};

// Adapter for CPU6V
class Debug6V : public IDebugTarget {
public:
    CPU6V cpu;
    explicit Debug6V(std::vector<uint32_t> prog) { cpu.load_program(prog); }
    RiscException step_one_macro() override { return cpu.step(); }
    RiscException step_one_micro() override { return cpu.step_micro(); }
    bool is_halted() const override { return cpu.halted; }
    RegisterFile const& regs() const override { return cpu.rf; }
    Memory const& memory() const override { return cpu.mem; }
    Stack const& stack_obj() const override { return cpu.stack; }
    std::string pipeline_snapshot() const override { return cpu.pipeline_snapshot(); }
    std::string regfile_snapshot() const override { return cpu.regfile_snapshot(); }
    std::string micro_snapshot() const override { return cpu.micro_snapshot(); }
    uint64_t cycle_count() const override { return cpu.cycle; }
    uint64_t retired_count() const override { return cpu.inst_retired; }
    std::string cpu_name() const override { return cpu.cpu_name(); }
    uint8_t current_upc() const override { return cpu.current_upc(); }
    uint64_t cycle_period_ps() const override { return cpu.cycle_period_ps(); }
    uint64_t elapsed_time_ps() const override { return cpu.elapsed_time_ps(); }
    bool packet_at_stage(int stage, uint32_t& pc, std::string& mnem,
                         bool& valid) const override {
        const PipePkt* p = nullptr;
        switch (stage) {
            case 0: p = &cpu.if_id; break;
            case 1: p = &cpu.id_of; break;
            case 2: p = &cpu.of_ex; break;
            case 3: p = &cpu.ex_ma; break;
            case 4: p = &cpu.ma_wb; break;
        }
        if (!p) { valid = false; return false; }
        valid = p->valid;
        pc = p->pc;
        if (p->valid) {
            // IF/ID holds the raw word (pre-decode): show its real opcode.
            mnem = (stage == 0) ? opcode_mnemonic(decode(p->inst_word).op)
                                : opcode_mnemonic(p->op);
        }
        return true;
    }
    uint64_t in_flight_now() const override {
        return (cpu.if_id.valid?1:0)+(cpu.id_of.valid?1:0)+(cpu.of_ex.valid?1:0)
             + (cpu.ex_ma.valid?1:0)+(cpu.ma_wb.valid?1:0);
    }
    uint64_t max_in_flight() const override { return cpu.max_in_flight; }
    uint64_t redirect_count() const override { return cpu.redirect_count; }
    uint64_t flushed_count() const override { return cpu.flushed_insts; }
    uint64_t bypass_count() const override { return cpu.bypass_hits; }
    uint64_t fetch_cycle_of_last_retired() const override { return cpu.wb_retire.fetch_cycle; }
    uint32_t last_retired_pc() const override { return cpu.wb_retire.pc; }
};

// ---------------------------------------------------------------------------
// Pipelined trace: prints one line per clock cycle showing which instruction
// occupies each stage (the reservation table), plus a retirement summary line
// whenever a macro instruction completes.
// ---------------------------------------------------------------------------
inline void trace_run(IDebugTarget& tgt, std::ostream& log, uint64_t max_cycles = 10000) {
    const char* regs6[5] = {"IF/ID", "ID/OF", "OF/EX", "EX/MA", "MA/WB"};
    const char* regs4[3] = {"IF/ID", "ID/EX", "EX/WB"};
    bool is6 = (tgt.cpu_name().find("6") != std::string::npos);
    log << "=== Risc201 pipelined trace (" << tgt.cpu_name() << ") ===\n";
    log << "  clock period: " << (tgt.cycle_period_ps() / 1000.0) << " ns/cycle"
        << "   (one line = one clock cycle; column = pipeline register contents; '-' = bubble)\n";

    auto ns = [](uint64_t ps) {
        std::ostringstream o;
        o << std::fixed << std::setprecision(3) << (ps / 1000.0) << "ns";
        return o.str();
    };

    // Header
    log << "   cyc |";
    int nstages = is6 ? 5 : 3;
    for (int s = 0; s < nstages; ++s) {
        const char* nm = is6 ? regs6[s] : regs4[s];
        log << " " << std::left << std::setw(13) << nm << "|";
    }
    log << " WB (retire)\n";

    for (uint64_t c = 0; c < max_cycles; ++c) {
        if (tgt.is_halted()) break;
        char linebuf[512];
        std::snprintf(linebuf, sizeof(linebuf), " %5llu |", (unsigned long long)(c + 1));
        log << linebuf;
        for (int s = 0; s < nstages; ++s) {
            uint32_t pc = 0; std::string mn; bool valid = false;
            tgt.packet_at_stage(s, pc, mn, valid);
            char cell[32];
            if (valid) std::snprintf(cell, sizeof(cell), "0x%02x %-5s", pc, mn.c_str());
            else       std::snprintf(cell, sizeof(cell), "-");
            char colbuf[64];
            std::snprintf(colbuf, sizeof(colbuf), " %-13s|", cell);
            log << colbuf;
        }
        // WB retire info comes after the cycle runs
        uint64_t ret_before = tgt.retired_count();
        auto ex = tgt.step_one_micro();
        uint64_t ret_after = tgt.retired_count();
        if (ret_after > ret_before) {
            uint64_t fc = tgt.fetch_cycle_of_last_retired();
            uint64_t lat = (tgt.cycle_count() > fc) ? (tgt.cycle_count() - fc) : 0;
            char rb[96];
            std::snprintf(rb, sizeof(rb), " 0x%02x *retired lat=%llucyc",
                          tgt.last_retired_pc(), (unsigned long long)lat);
            log << rb;
        }
        log << "\n";
        if (ex.kind != ExKind::None && ex.kind != ExKind::Halt) {
            log << "  ABORT@" << exkind_name(ex.kind)
                << " pc=0x" << std::hex << ex.pc << std::dec
                << " - " << ex.message << "\n";
            break;
        }
    }

    log << "\n=== Final state ===\n";
    log << tgt.regfile_snapshot();
    log << tgt.pipeline_snapshot();
    double cpi = tgt.retired_count() ? (double)tgt.cycle_count() / (double)tgt.retired_count() : 0.0;
    log << "  cycles=" << std::dec << tgt.cycle_count()
        << "  retired=" << tgt.retired_count()
        << "  CPI=" << std::fixed << std::setprecision(2) << cpi
        << "  max-in-flight=" << tgt.max_in_flight()
        << "  redirects=" << tgt.redirect_count()
        << "  flushed=" << tgt.flushed_count()
        << "  bypasses=" << tgt.bypass_count()
        << "  time=" << ns(tgt.elapsed_time_ps()) << "\n";
}

// Interactive REPL debugger
inline void interactive_repl(IDebugTarget& tgt, std::istream& in, std::ostream& out) {
    out << "Risc201 interactive debugger (" << tgt.cpu_name()
        << ", OPERATIONAL pipelined, vertical µcode)\n";
    out << "Commands: s/step | m/cycle | r/regs | p/pipeline | u/µseq-state | "
           "d <addr>/disasm | mem <addr> | st/stack | cs/check-stack | "
           "c <n>/run-n | h/help | q/quit\n";
    while (!tgt.is_halted()) {
        out << "risc201(" << tgt.cpu_name() << ") pc=0x"
            << std::hex << tgt.regs().pc
            << " cyc=" << std::dec << tgt.cycle_count()
            << " retired=" << tgt.retired_count() << "> ";
        std::string line;
        if (!std::getline(in, line)) break;
        // trim
        while (!line.empty() && (line.front()==' '||line.front()=='\t')) line.erase(line.begin());
        while (!line.empty() && (line.back()==' '||line.back()=='\t'||line.back()=='\r'||line.back()=='\n')) line.pop_back();
        if (line.empty()) continue;
        std::vector<std::string> ws;
        { std::istringstream ss(line); std::string t; while (ss >> t) ws.push_back(t); }
        std::string cmd = ws[0];
        for (auto& c : cmd) c = (char)toupper(c);

        if (cmd == "Q" || cmd == "QUIT" || cmd == "EXIT") { out << "bye.\n"; return; }
        if (cmd == "H" || cmd == "HELP" || cmd == "?") {
            out << "  s   run until the next instruction retires (macro step)\n"
                << "  m   step ONE CLOCK CYCLE (every stage interprets its µops)\n"
                << "  r   show register file + flags\n"
                << "  p   show pipeline snapshot (packet + µPC per stage)\n"
                << "  u   show per-stage microcode sequencer state (µPCs)\n"
                << "  d <addr>   disassemble 16 instructions starting at addr\n"
                << "  mem <addr> dump 16 memory words starting at addr\n"
                << "  st  show stack visualizer\n"
                << "  cs  check stack safety\n"
                << "  c <n>  run up to n macro steps (or until halt)\n"
                << "  h   this help\n";
            continue;
        }
        if (cmd == "S" || cmd == "STEP") {
            auto ex = tgt.step_one_macro();
            out << "  step: " << exkind_name(ex.kind)
                << (ex.message.empty() ? "" : (": " + ex.message)) << "\n";
            out << tgt.regfile_snapshot();
            continue;
        }
        if (cmd == "M" || cmd == "MICRO" || cmd == "CYCLE") {
            auto ex = tgt.step_one_micro();
            out << "  cycle: " << exkind_name(ex.kind)
                << (ex.message.empty() ? "" : (": " + ex.message)) << "\n";
            out << tgt.pipeline_snapshot();
            continue;
        }
        if (cmd == "R" || cmd == "REGS") { out << tgt.regfile_snapshot(); continue; }
        if (cmd == "P" || cmd == "PIPE") { out << tgt.pipeline_snapshot(); continue; }
        if (cmd == "U" || cmd == "UPC" || cmd == "MICROSTATE") {
            out << tgt.micro_snapshot(); continue;
        }
        if (cmd == "ST" || cmd == "STACK") { out << tgt.stack_obj().visualize(16); continue; }
        if (cmd == "CS" || cmd == "CHECK") {
            bool ok = tgt.stack_obj().verify();
            out << "  stack safety: " << (ok ? "OK" : "VIOLATED") << "\n";
            continue;
        }
        if (cmd == "C" || cmd == "RUN") {
            int n = ws.size() > 1 ? std::stoi(ws[1]) : 1000;
            for (int i = 0; i < n; ++i) {
                if (tgt.is_halted()) { out << "  halted.\n"; break; }
                auto ex = tgt.step_one_macro();
                if (ex.kind != ExKind::None && ex.kind != ExKind::Halt) {
                    out << "  abort: " << exkind_name(ex.kind) << ": " << ex.message << "\n";
                    break;
                }
                if (ex.kind == ExKind::Halt) { out << "  halted.\n"; break; }
            }
            out << tgt.regfile_snapshot();
            continue;
        }
        if (cmd == "D" || cmd == "DIS") {
            uint32_t addr = ws.size() > 1 ? (uint32_t)std::stoul(ws[1], nullptr, 0) : tgt.regs().pc;
            for (int i = 0; i < 16; ++i) {
                uint32_t a = addr + (uint32_t)i * 4;
                uint32_t w = tgt.memory().read_word(a);
                char buf[128];
                std::snprintf(buf, sizeof(buf), "  0x%06x: 0x%08x  ", a, w);
                out << buf << disasm_text(decode(w), a) << "\n";
            }
            continue;
        }
        if (cmd == "MEM") {
            uint32_t addr = ws.size() > 1 ? (uint32_t)std::stoul(ws[1], nullptr, 0) : tgt.regs().sp();
            for (int i = 0; i < 16; ++i) {
                uint32_t a = addr + (uint32_t)i * 4;
                uint32_t w = tgt.memory().read_word(a);
                char buf[128];
                std::snprintf(buf, sizeof(buf), "  0x%06x: 0x%08x\n", a, w);
                out << buf;
            }
            continue;
        }
        out << "  unknown command '" << ws[0] << "' (type 'h' for help)\n";
    }
    out << "=== CPU halted ===\n";
    out << tgt.regfile_snapshot();
    double cpi = tgt.retired_count() ? (double)tgt.cycle_count() / (double)tgt.retired_count() : 0.0;
    out << "  total cycles=" << std::dec << tgt.cycle_count()
        << "  instructions retired=" << tgt.retired_count()
        << "  CPI=" << std::fixed << std::setprecision(2) << cpi << "\n";
}

} // namespace risc201
