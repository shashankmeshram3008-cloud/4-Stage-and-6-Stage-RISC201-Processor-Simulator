// risc201/cpu6.hpp — 6-stage Risc201 CPU (OPERATIONAL pipelined, vertical microcode).
//
// CPU6V drives a true overlapping 6-stage pipeline
// (IF -> ID -> OF -> EX -> MA -> WB) controlled END-TO-END by the vertical
// microcode ROM (32-bit µword, 1 action per µop, ~5 µops/macro).
//
//   IF  : µop FETCH_IR   — IR <- MEM[PC]; PC <- PC+4 (or branch target).
//   ID  : µop DECODE     — µPC <- dispatch_table[opcode]; extract fields.
//   OF  : µop OF_READ    — A/B/op2 <- regfile (with forwarding).
//   EX  : µops ALU_OP, SET_FLAGS, COMPUTE_TARGET, COND_BRANCH,
//              PC_LOAD_TARGET, LINK_RA  — compute / resolve / redirect.
//   MA  : µops MEM_READ, MEM_WRITE — data memory access.
//   WB  : µop REG_WRITE  — R[rd] <- result; retirement (JMP_MICRO -> FETCH).
//
// WHAT MAKES IT OPERATIONAL (vs the previous sequential model):
//   * Each in-flight instruction CARRIES ITS OWN µPC in the pipeline
//     registers; every stage is a vertical µop interpreter for the µops
//     statically assigned to it. Several instructions are in flight at
//     once, each executing its own microcode sequence concurrently.
//   * IF fetches a new instruction every cycle; WB retires one every
//     cycle. CPI -> 1 in straight-line code.
//   * Every control signal still comes from the ROM: no hardwired logic.
//   * JMP_MICRO -> FETCH is the retirement marker consumed by WB.
//
// HAZARD HANDLING (still ROM-driven):
//   * RAW data hazards: full bypassing into OF (EX same-cycle, EX/MA,
//     MA same-cycle load, MA/WB, regfile write-first) -> zero stalls.
//   * Flags & ra: committed by EX-stage µops (SET_FLAGS / LINK_RA) so a
//     following branch in EX never sees stale state.
//   * PC-redirecting µops (COND_BRANCH / PC_LOAD_TARGET) execute in EX:
//     younger instructions have only fetched/decoded/read operands by
//     then, so squashing IF/ID, ID/OF, OF/EX is architecturally precise.
//     Taken branch penalty = 3 bubbles; not-taken = 0.
//
// All ALU work goes through alu.hpp (CLA adder, Booth radix-2 mul,
// Goldschmidt div). No hardwired logic — every control signal is sourced
// from the control memory (the vertical microcode ROM).

#pragma once

#include "isa.hpp"
#include "alu.hpp"
#include "core.hpp"
#include <array>
#include <vector>
#include <string>
#include <cstdint>

namespace risc201 {

// =====================================================================
// Part 1 — VERTICAL microcode (32-bit µword, 1 action per µop)
// =====================================================================

enum class VAction : uint8_t {
    NOP = 0,
    FETCH_IR,        // IF  : IR = MEM[PC]; PC += 4 (or redirected target)
    DECODE,          // ID  : µPC = dispatch_table[opcode]; extract fields
    OF_READ,         // OF  : read rs1, rs2 (or expand imm) into A, B, op2
    ALU_OP,          // EX  : ALU(arg1=opcode); srcA = A, srcB = B
    REG_WRITE,       // WB  : R[rd] = result
    SET_FLAGS,       // EX  : flags = ALUout.flags   (early commit, no hazard)
    MEM_READ,        // MA  : MAR = A + imm; MDR = MEM[MAR]; result = MDR
    MEM_WRITE,       // MA  : MAR = A + imm; MEM[MAR] = op2
    COMPUTE_TARGET,  // EX  : mdr = pkt.pc + offset*4 (branch target)
    PC_LOAD_TARGET,  // EX  : PC = mdr (b/call) or PC = R[ra] (ret) + redirect
    LINK_RA,         // EX  : R[ra] = pkt.pc + 4 (call link; early commit)
    COND_BRANCH,     // EX  : if cond(flags) then PC = mdr + redirect
    HALT,            // stop CPU
    JMP_MICRO,       // µPC = (arg1<<8 | arg2); -> FETCH marks retirement
};

struct VMicroOp {
    uint8_t action;   // VAction
    uint8_t arg1;
    uint8_t arg2;
    uint8_t cond;     // condition code for COND_BRANCH
};

inline const char* vaction_name(VAction a) {
    switch (a) {
        case VAction::NOP:            return "NOP";
        case VAction::FETCH_IR:       return "FETCH_IR";
        case VAction::DECODE:         return "DECODE";
        case VAction::OF_READ:       return "OF_READ";
        case VAction::ALU_OP:        return "ALU_OP";
        case VAction::REG_WRITE:     return "REG_WRITE";
        case VAction::SET_FLAGS:     return "SET_FLAGS";
        case VAction::MEM_READ:      return "MEM_READ";
        case VAction::MEM_WRITE:     return "MEM_WRITE";
        case VAction::COMPUTE_TARGET:return "COMPUTE_TGT";
        case VAction::PC_LOAD_TARGET:return "PC_LOAD_TGT";
        case VAction::LINK_RA:       return "LINK_RA";
        case VAction::COND_BRANCH:   return "COND_BRANCH";
        case VAction::HALT:          return "HALT";
        case VAction::JMP_MICRO:     return "JMP_MICRO";
    }
    return "?";
}

enum VCond : uint8_t {
    VC_ALWAYS = 0,
    VC_E, VC_NE, VC_GT, VC_NGT,
};

inline bool eval_vcond(VCond c, Flags f) {
    switch (c) {
        case VC_ALWAYS: return true;
        case VC_E:   return f.E;
        case VC_NE:  return !f.E;
        case VC_GT:  return f.GT;
        case VC_NGT: return !f.GT;
    }
    return false;
}

// =====================================================================
// Part 2 — Stage µop assignment (the pipeline "control plan")
// =====================================================================
//
// The SAME vertical ROM is used as in the sequential model; what changed
// is WHO interprets each µword. Each µop is statically assigned to the
// stage that owns its resource:

inline bool upc_is_if_local(VAction a) { return a == VAction::FETCH_IR; }
inline bool upc_is_id_local(VAction a) { return a == VAction::DECODE; }
inline bool upc_is_of_local(VAction a) { return a == VAction::OF_READ; }
inline bool upc_is_ex_local(VAction a) {
    return a == VAction::ALU_OP || a == VAction::SET_FLAGS ||
           a == VAction::COMPUTE_TARGET || a == VAction::COND_BRANCH ||
           a == VAction::PC_LOAD_TARGET || a == VAction::LINK_RA;
}
inline bool upc_is_ma_local(VAction a) {
    return a == VAction::MEM_READ || a == VAction::MEM_WRITE;
}
inline bool upc_is_wb_local(VAction a) { return a == VAction::REG_WRITE; }

// Pipeline order of each µop (IF=0 .. WB=5); -1 = sequencer-only µword.
// Every ROM routine is emitted in this order, so a packet in stage S has
// always consumed every µop of order < S: a stage skips consumed µwords,
// executes its own, and stops at µwords owned by later stages.
inline int upc_stage_order(VAction a) {
    if (a == VAction::FETCH_IR)  return 0;
    if (a == VAction::DECODE)    return 1;
    if (a == VAction::OF_READ)   return 2;
    if (upc_is_ex_local(a))      return 3;
    if (upc_is_ma_local(a))      return 4;
    if (upc_is_wb_local(a))      return 5;
    return -1;                                   // NOP / HALT / JMP_MICRO
}

// =====================================================================
// Part 3 — Instruction packet (travels through the pipeline registers)
// =====================================================================
//
// One unified packet type for every pipeline register. The per-instruction
// µPC travels inside the packet — this is what makes the pipeline fully
// vertical-controlled: each stage reads the µword addressed by the packet's
// µPC and executes only the actions assigned to it.

struct PipePkt {
    uint32_t inst_word  = 0;
    uint32_t pc         = 0;       // instruction's own address
    Opcode   op         = OP_NOP;
    uint8_t  rd         = 0;
    uint8_t  rs1        = 0;
    uint8_t  rs2        = 0;
    int32_t  imm        = 0;
    Modifier mod        = Modifier::DEFAULT;
    bool     is_imm     = false;
    int32_t  offset     = 0;
    bool     writes_back= false;
    uint8_t  upc        = 0;       // ← per-instruction micro program counter
    uint32_t A           = 0;      // operand 1 (rs1 value), captured in OF
    uint32_t B           = 0;      // operand 2 (rs2 value or expanded imm)
    uint32_t op2         = 0;      // store data (rd value) for st
    uint32_t result      = 0;      // ALU result or loaded data
    bool     result_ready= false;  // result available for bypass
    bool     is_load     = false;
    bool     is_store    = false;
    bool     valid       = false;
    uint64_t fetch_cycle = 0;      // cycle in which IF fetched this packet
};

using IF_ID = PipePkt;
using ID_OF = PipePkt;
using OF_EX = PipePkt;
using EX_MA = PipePkt;
using MA_WB = PipePkt;

// =====================================================================
// Part 4 — ROM container (unchanged layout: same µwords as before)
// =====================================================================

constexpr int VROM_SIZE = 256;

struct VerticalMicrocode {
    std::array<VMicroOp, VROM_SIZE> rom{};
    std::array<uint8_t, 32> dispatch{};
    VerticalMicrocode() { build(); }
private:
    void build();
};

// =====================================================================
// Part 5 — CPU6V (6-stage operational pipeline, vertical microcode)
// =====================================================================

// Synthetic clock-period model (in picoseconds) — unchanged from the
// sequential model: critical path = max(t_IF, t_EX, t_MA) ≈ 700 ps.
constexpr uint64_t CYCLE_PERIOD_PS = 770;   // 6-stage clock period: 0.77 ns

class CPU6V {
public:
    Memory       mem;
    RegisterFile rf{};
    Stack        stack;
    VerticalMicrocode vuc;

    // Pipeline registers — each holds one instruction packet.
    IF_ID  if_id;
    ID_OF  id_of;
    OF_EX  of_ex;
    EX_MA  ex_ma;
    MA_WB  ma_wb;
    MA_WB  wb_retire;     // last retired packet (debugger view)

    // Machine state
    bool     halted = false;
    uint64_t cycle  = 0;
    uint64_t inst_retired = 0;

    // Hazard-control signals
    bool     flush_pending = false;   // set by EX redirect, applied next cycle
    uint32_t redirect_target = 0;
    bool     stream_end    = false;  // zero word seen: drain, then halt

    // Shared datapath registers (debugger-visible)
    AluOut   alu_out{};
    uint32_t mar = 0;
    uint32_t mdr = 0;

    // Statistics
    uint64_t redirect_count  = 0;   // taken/unconditional PC redirects
    uint64_t flush_events    = 0;   // squashes (one per redirect)
    uint64_t flushed_insts   = 0;   // packets squashed by redirects
    uint64_t bypass_hits     = 0;   // operand captures served by forwarding
    uint64_t load_stall_cycles = 0; // load-use interlock bubbles
    uint64_t max_in_flight   = 0;   // peak concurrently in-flight packets

    std::vector<uint32_t> breakpoints;

    CPU6V() : mem(MEM_SIZE * 4), stack(mem, rf) {
        rf.pc = 0; rf.sp() = STACK_BASE;
    }

    void load_program(const std::vector<uint32_t>& words, uint32_t at = 0) {
        for (uint32_t i = 0; i < words.size() && at + i * 4 < mem.size_bytes; ++i)
            mem.write_word(at + i * 4, words[i]);
        rf.pc = at; rf.sp() = STACK_BASE; rf.ra() = 0;
        if_id = PipePkt{}; id_of = PipePkt{}; of_ex = PipePkt{};
        ex_ma = PipePkt{}; ma_wb = PipePkt{}; wb_retire = PipePkt{};
        halted = false; cycle = 0; inst_retired = 0;
        flush_pending = false; redirect_target = 0; stream_end = false;
        alu_out = {}; mar = 0; mdr = 0;
        redirect_count = 0; flush_events = 0; flushed_insts = 0;
        bypass_hits = 0; load_stall_cycles = 0; max_in_flight = 0;
    }

    // Core clock edge: executes all six stages once (WB -> MA -> EX ->
    // OF -> ID -> IF), then applies a pending flush. This is the
    // "one clock cycle" of the operational pipeline.
    RiscException step_cycle();

    // Interface compat: one clock cycle ("micro step" of the machine).
    RiscException step_micro();

    // Run until the next instruction retires (or exception/halt).
    RiscException step();

    std::string pipeline_snapshot() const;
    std::string regfile_snapshot() const;
    std::string micro_snapshot() const;
    std::string cpu_name() const { return "Risc201-6stage"; }
    uint8_t  current_upc() const;    // µPC of the most-advanced packet

    // Timing model — see CYCLE_PERIOD_PS above.
    uint64_t cycle_period_ps() const { return CYCLE_PERIOD_PS; }
    uint64_t elapsed_time_ps() const { return cycle * CYCLE_PERIOD_PS; }

private:
    // Per-stage µop interpreters (each walks the ROM from pkt.upc).
    // Return: 0 = pass-through, 1 = executed µops, 2 = retired (WB only).
    int  wb_step(RiscException& ex);
    void ma_step();
    void ex_step(RiscException& ex);
    void of_step(bool stalled);
    void id_step(bool stalled);
    void if_step(uint32_t fetch_pc, bool stalled);
    bool detect_of_stall() const;   // load-use interlock

    // Forwarding networks (bypass muxes)
    uint32_t fwd_of(uint8_t reg, uint32_t rf_val);
    uint32_t fwd_ex_ra();           // ret's R[ra] read in EX

    // Same-cycle forwarding channels, refreshed each cycle
    bool     ex_fwd_valid = false;  // EX produced an ALU result this cycle
    uint8_t  ex_fwd_rd    = 0;
    uint32_t ex_fwd_val   = 0;
    bool     ma_fwd_valid = false;  // MA produced load data this cycle
    uint8_t  ma_fwd_rd    = 0;
    uint32_t ma_fwd_val   = 0;

    void count_in_flight();
};

} // namespace risc201
