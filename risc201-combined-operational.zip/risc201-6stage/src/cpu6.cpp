// risc201/src/cpu6.cpp — 6-stage Risc201 CPU (OPERATIONAL pipelined, vertical µcode).
//
// Pipeline: IF -> ID -> OF -> EX -> MA -> WB  (instructions OVERLAP)
//
// The vertical ROM is µword-identical to the sequential model's ROM. What
// changed is the interpretation model: each stage walks the µword at the
// in-flight instruction's µPC and executes only the µops statically
// assigned to it (see upc_is_*_local predicates in cpu6.hpp). The µPC
// travels inside the instruction packet, so several independent microcode
// sequences execute concurrently — one per occupied pipeline stage.
//
// Defines:
//   VerticalMicrocode::build()   — fills the vertical ROM (unchanged µwords)
//   CPU6V::step_cycle()          — one clock edge of the pipelined machine
//   CPU6V::step_micro() / step() / snapshots

#include "risc201/cpu6.hpp"
#include <sstream>
#include <iomanip>
#include <cstdio>

namespace risc201 {

// =====================================================================
// ROM builder — µword layout IDENTICAL to the sequential model.
//   rom[0] = FETCH_IR, rom[1] = JMP->DECODE, rom[2] = DECODE
//   routine(opcode) at 16 + opcode*4, terminated by JMP->FETCH
// =====================================================================

static inline VMicroOp M(uint8_t action, uint8_t a1 = 0, uint8_t a2 = 0, uint8_t cond = 0) {
    return VMicroOp{action, a1, a2, cond};
}

static constexpr uint8_t V_ENTRY_FETCH   = 0;
static constexpr uint8_t V_ENTRY_DECODE  = 2;
static constexpr uint8_t V_ENTRY_HALT    = 250;

void VerticalMicrocode::build() {
    for (auto& m : rom) m = M((uint8_t)VAction::NOP);
    for (auto& d : dispatch) d = V_ENTRY_HALT;

    rom[V_ENTRY_FETCH]    = M((uint8_t)VAction::FETCH_IR);
    rom[V_ENTRY_FETCH+1] = M((uint8_t)VAction::JMP_MICRO, 0, V_ENTRY_DECODE);
    rom[V_ENTRY_DECODE]  = M((uint8_t)VAction::DECODE);

    auto emit_routine = [&](uint8_t opcode, std::vector<VMicroOp> body) {
        uint8_t entry = (uint8_t)(16 + opcode * 4);
        size_t i = 0;
        for (; i < body.size() && i < 3; ++i)
            rom[entry + i] = body[i];
        rom[entry + i] = M((uint8_t)VAction::JMP_MICRO, 0, V_ENTRY_FETCH);
        dispatch[opcode] = entry;
    };

    emit_routine(OP_NOP, {});

    auto alu_r = [&](Opcode op) {
        emit_routine(op, {
            M((uint8_t)VAction::OF_READ),
            M((uint8_t)VAction::ALU_OP, (uint8_t)op),
            M((uint8_t)VAction::REG_WRITE),
        });
    };
    alu_r(OP_ADD); alu_r(OP_SUB); alu_r(OP_MUL); alu_r(OP_DIV); alu_r(OP_MOD);
    alu_r(OP_AND); alu_r(OP_OR);
    alu_r(OP_LSL); alu_r(OP_LSR); alu_r(OP_ASR);

    emit_routine(OP_CMP, {
        M((uint8_t)VAction::OF_READ),
        M((uint8_t)VAction::ALU_OP, (uint8_t)OP_CMP),
        M((uint8_t)VAction::SET_FLAGS),
    });

    emit_routine(OP_MOV, {
        M((uint8_t)VAction::OF_READ),
        M((uint8_t)VAction::ALU_OP, (uint8_t)OP_MOV),
        M((uint8_t)VAction::REG_WRITE),
    });
    emit_routine(OP_NOT, {
        M((uint8_t)VAction::OF_READ),
        M((uint8_t)VAction::ALU_OP, (uint8_t)OP_NOT),
        M((uint8_t)VAction::REG_WRITE),
    });

    emit_routine(OP_LD, {
        M((uint8_t)VAction::OF_READ),
        M((uint8_t)VAction::MEM_READ),
        M((uint8_t)VAction::REG_WRITE),
    });

    emit_routine(OP_ST, {
        M((uint8_t)VAction::OF_READ),
        M((uint8_t)VAction::MEM_WRITE),
    });

    emit_routine(OP_B, {
        M((uint8_t)VAction::COMPUTE_TARGET),
        M((uint8_t)VAction::PC_LOAD_TARGET),
    });

    emit_routine(OP_BEQ, {
        M((uint8_t)VAction::COMPUTE_TARGET),
        M((uint8_t)VAction::COND_BRANCH, 0, 0, VC_E),
    });

    emit_routine(OP_BGT, {
        M((uint8_t)VAction::COMPUTE_TARGET),
        M((uint8_t)VAction::COND_BRANCH, 0, 0, VC_GT),
    });

    emit_routine(OP_CALL, {
        M((uint8_t)VAction::LINK_RA),
        M((uint8_t)VAction::COMPUTE_TARGET),
        M((uint8_t)VAction::PC_LOAD_TARGET),
    });

    emit_routine(OP_RET, {
        M((uint8_t)VAction::PC_LOAD_TARGET),
    });

    rom[V_ENTRY_HALT]   = M((uint8_t)VAction::HALT);
    rom[V_ENTRY_HALT+1] = M((uint8_t)VAction::NOP);
    rom[V_ENTRY_HALT+2] = M((uint8_t)VAction::JMP_MICRO, 0, V_ENTRY_HALT);
}

// =====================================================================
// Forwarding networks (bypass muxes)
// =====================================================================

// Does this packet read `reg` as a source GPR? (Branches/call/ret/nop read
// no GPRs; ret's ra read happens in EX and has its own bypass.)
static bool pkt_reads_reg(const PipePkt& p, uint8_t reg) {
    switch (p.op) {
        case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD:
        case OP_CMP: case OP_AND: case OP_OR:
        case OP_LSL: case OP_LSR: case OP_ASR:
            return p.rs1 == reg || (!p.is_imm && p.rs2 == reg);
        case OP_MOV: case OP_NOT:
            return !p.is_imm && p.rs2 == reg;
        case OP_LD:
            return p.rs1 == reg;
        case OP_ST:
            return p.rs1 == reg || p.rd == reg;
        default:
            return false;
    }
}

// Operand-fetch bypass. Priority = youngest producer first:
//   EX same-cycle ALU result > EX/MA result > MA same-cycle load data
//   > MA/WB result > regfile (WB already wrote this cycle).
uint32_t CPU6V::fwd_of(uint8_t reg, uint32_t rf_val) {
    if (ex_fwd_valid && ex_fwd_rd == reg) { bypass_hits++; return ex_fwd_val; }
    if (ex_ma.valid && ex_ma.result_ready && ex_ma.writes_back && ex_ma.rd == reg) {
        bypass_hits++; return ex_ma.result;
    }
    if (ma_fwd_valid && ma_fwd_rd == reg) { bypass_hits++; return ma_fwd_val; }
    if (ma_wb.valid && ma_wb.result_ready && ma_wb.writes_back && ma_wb.rd == reg) {
        bypass_hits++; return ma_wb.result;
    }
    return rf_val;
}

// EX-stage bypass for ret's R[ra] read (PC_LOAD_TARGET µop).
// By the time EX runs, EX/MA has already been drained into MA/WB, so the
// youngest possible producer sits in MA/WB; anything older has been
// written to the regfile by this cycle's WB step (write-first convention).
uint32_t CPU6V::fwd_ex_ra() {
    if (ma_wb.valid && ma_wb.result_ready && ma_wb.writes_back && ma_wb.rd == RA_REG) {
        bypass_hits++; return ma_wb.result;
    }
    return rf.ra();
}

// =====================================================================
// Per-stage microcode interpreters.
// Each walks the ROM from the packet's µPC, executing only its own µops,
// then forwards the packet (with the advanced µPC) to the next register.
// =====================================================================

// WB: interpret WB-local µops; JMP->FETCH = retire (end of microprogram).
int CPU6V::wb_step(RiscException& ex) {
    if (!ma_wb.valid) return 0;
    for (int guard = 0; guard < 8; ++guard) {
        const VMicroOp& m = vuc.rom[ma_wb.upc];
        VAction a = (VAction)m.action;
        if (a == VAction::JMP_MICRO) {
            uint16_t tgt = (uint16_t)((m.arg1 << 8) | m.arg2);
            if (tgt == V_ENTRY_FETCH) {
                wb_retire = ma_wb;          // retirement snapshot (debugger)
                ma_wb = PipePkt{};
                inst_retired++;
                return 2;
            }
            ma_wb.upc = (uint8_t)tgt;       // other glue jumps: resolve & continue
            continue;
        }
        if (upc_is_wb_local(a)) {
            // REG_WRITE: R[rd] <- result, with SP floor check (StackOverflow).
            const InstrInfo* info = info_by_opcode(ma_wb.op);
            if (info && info->writes_reg)
                rf.write(ma_wb.rd, ma_wb.result);
            if (ma_wb.rd == SP_REG && rf.sp() < STACK_LIMIT) {
                char buf[96];
                std::snprintf(buf, sizeof(buf),
                    "SP=0x%08x crossed stack floor (LIMIT=0x%08x)",
                    rf.sp(), STACK_LIMIT);
                ex = { ExKind::StackOverflow, ma_wb.pc, buf };
                return 1;
            }
            ma_wb.upc++;
            continue;
        }
        return 0;   // nothing for WB this cycle (pass-through)
    }
    return 0;
}

// MA: interpret MA-local µops (memory access), then advance to MA/WB.
// MA/WB is always free here because WB retired its packet this cycle.
void CPU6V::ma_step() {
    ma_fwd_valid = false;
    if (!ex_ma.valid) { ma_wb = PipePkt{}; return; }
    PipePkt p = ex_ma;
    for (int guard = 0; guard < 8; ++guard) {
        const VMicroOp& m = vuc.rom[p.upc];
        VAction a = (VAction)m.action;
        if (a == VAction::JMP_MICRO) break;             // retire marker: handled in WB
        int ord = upc_stage_order(a);
        if (ord == 4) {                                 // MA-local µop
            if (a == VAction::MEM_READ) {
                uint32_t addr = p.A + (uint32_t)p.imm;
                mar = addr; mdr = mem.read_word(addr);
                p.result = mdr; p.result_ready = true;
                if (p.is_load) { ma_fwd_valid = true; ma_fwd_rd = p.rd; ma_fwd_val = mdr; }
            } else if (a == VAction::MEM_WRITE) {
                uint32_t addr = p.A + (uint32_t)p.imm;
                mar = addr; mdr = p.op2;
                mem.write_word(addr, p.op2);
            }
            p.upc++;
            continue;
        }
        if (ord >= 0 && ord < 4) { p.upc++; continue; } // consumed upstream: skip
        break;
    }
    ma_wb = p; ma_wb.valid = true;
    ex_ma = PipePkt{};
}

// EX: the compute/resolve stage. May execute several µops of the SAME
// instruction in one clock (cmp: ALU_OP then SET_FLAGS; call: LINK_RA +
// COMPUTE_TARGET + PC_LOAD_TARGET) — each still a separate vertical µword.
// PC-redirecting µops set flush_pending for the NEXT cycle.
void CPU6V::ex_step(RiscException& ex) {
    ex_fwd_valid = false;
    if (!of_ex.valid) { ex_ma = PipePkt{}; return; }
    PipePkt p = of_ex;
    bool produced_alu = false;
    bool redirect = false;
    for (int guard = 0; guard < 8; ++guard) {
        const VMicroOp& m = vuc.rom[p.upc];
        VAction a = (VAction)m.action;
        if (a == VAction::JMP_MICRO) break;             // retire marker: handled in WB
        if (!upc_is_ex_local(a)) break;                 // pass-through cycle
        switch (a) {
            case VAction::ALU_OP: {
                Opcode opcode = (Opcode)m.arg1;
                alu_out = alu_execute(opcode, p.A, p.B);
                if (alu_out.exception == 1) {
                    // Precise exception: squash every younger packet.
                    flushed_insts += (if_id.valid ? 1 : 0) + (id_of.valid ? 1 : 0);
                    if_id = PipePkt{}; id_of = PipePkt{};
                    of_ex = PipePkt{};
                    ex = { ExKind::DivByZero, p.pc, "Division by zero in EX (Goldschmidt)" };
                    halted = true;
                    return;
                }
                p.result = alu_out.value; p.result_ready = true;
                produced_alu = true;
                break;
            }
            case VAction::SET_FLAGS:
                rf.flags = alu_out.flags;               // early commit: no flags hazard
                break;
            case VAction::COMPUTE_TARGET:
                mdr = p.pc + (uint32_t)(p.offset * 4);  // target = pkt.pc + offset*4
                break;
            case VAction::PC_LOAD_TARGET:
                rf.pc = (p.op == OP_RET) ? fwd_ex_ra() : mdr;
                redirect = true;
                break;
            case VAction::LINK_RA:
                rf.ra() = p.pc + 4;                     // early commit: no ra hazard
                break;
            case VAction::COND_BRANCH: {
                VCond c = (VCond)m.cond;
                if (eval_vcond(c, rf.flags)) { rf.pc = mdr; redirect = true; }
                break;
            }
            default: break;
        }
        p.upc++;
    }
    // Same-cycle ALU bypass channel for this cycle's OF read (youngest producer).
    if (produced_alu && p.writes_back) {
        ex_fwd_valid = true; ex_fwd_rd = p.rd; ex_fwd_val = p.result;
    }
    if (redirect) {
        flush_pending = true;
        redirect_target = rf.pc;
        redirect_count++; flush_events++;
        stream_end = false;   // redirect resumes the stream (e.g. loop back-edge)
    }
    ex_ma = p; ex_ma.valid = true;                     // advance (MA/WB freed by WB)
    of_ex = PipePkt{};
}

// OF: interpret OF_READ with the forwarding network; capture A/B/op2.
// Branches simply pass through: their routine has no OF µword, and the
// walk only executes µops assigned to this stage.
// On a load-use stall the packet stays in ID/OF and a bubble is injected.
void CPU6V::of_step(bool stalled) {
    if (stalled || !id_of.valid) { of_ex = PipePkt{}; return; }
    PipePkt p = id_of;
    for (int guard = 0; guard < 8; ++guard) {
        const VMicroOp& m = vuc.rom[p.upc];
        VAction a = (VAction)m.action;
        if (a == VAction::JMP_MICRO) break;             // retire marker: handled in WB
        int ord = upc_stage_order(a);
        if (ord == 2) {                                 // OF-local µop
            if (a == VAction::OF_READ) {
                p.A   = fwd_of(p.rs1, rf.read(p.rs1));
                if (p.is_imm) p.B = (uint32_t)p.imm;
                else          p.B = fwd_of(p.rs2, rf.read(p.rs2));
                p.op2 = (p.op == OP_ST) ? fwd_of(p.rd, rf.read(p.rd)) : p.B;
            }
            p.upc++;
            continue;
        }
        if (ord >= 0 && ord < 2) { p.upc++; continue; } // consumed upstream: skip
        break;                                          // later-stage µword: stop
    }
    of_ex = p; of_ex.valid = true;                     // advance (EX freed by EX)
    id_of = PipePkt{};
}

// ID: interpret DECODE — resolve glue jump, dispatch µPC, extract fields.
// On a load-use stall the packet holds in IF/ID (re-decoded next cycle).
void CPU6V::id_step(bool stalled) {
    if (stalled || !if_id.valid) { return; }   // hold if_id; id_of untouched
    PipePkt p = if_id;
    for (int guard = 0; guard < 8; ++guard) {
        const VMicroOp& m = vuc.rom[p.upc];
        VAction a = (VAction)m.action;
        if (a == VAction::JMP_MICRO) {
            p.upc = (uint8_t)((m.arg1 << 8) | m.arg2);  // glue: FETCH -> DECODE
            continue;
        }
        int ord = upc_stage_order(a);
        if (ord == 1) {                                 // DECODE
            Decoded d = decode(p.inst_word);
            p.op = d.op; p.rd = d.rd; p.rs1 = d.rs1; p.rs2 = d.rs2;
            p.imm = d.imm; p.mod = d.mod; p.is_imm = d.is_immediate;
            p.offset = d.offset;
            const InstrInfo* info = info_by_opcode(p.op);
            p.writes_back = (info && info->writes_reg);
            p.is_load  = (p.op == OP_LD);
            p.is_store = (p.op == OP_ST);
            p.upc = vuc.dispatch[(uint8_t)p.op];        // µPC <- dispatch_table[opcode]
            break;
        }
        if (ord >= 0 && ord < 1) { p.upc++; continue; } // consumed upstream: skip FETCH_IR
        break;
    }
    id_of = p; id_of.valid = true;                     // advance (OF freed by OF)
    if_id = PipePkt{};
}

// Load-use interlock: a load in EX (input register OF/EX) will read memory
// in MA NEXT cycle, but a dependent instruction in OF reads registers THIS
// cycle — one cycle too early. Hold the consumer in OF for one cycle; on
// the retry the load's fresh data arrives through the MA same-cycle bypass.
bool CPU6V::detect_of_stall() const {
    if (!of_ex.valid || !of_ex.is_load || !id_of.valid) return false;
    const PipePkt& ld = of_ex;
    const PipePkt& cn = id_of;
    return pkt_reads_reg(cn, ld.rd);
}

// IF: interpret FETCH_IR — read MEM[fetch_pc], form the packet, PC += 4.
// fetch_pc is the address latched at cycle start; an EX redirect issued
// this cycle reaches the fetch on the NEXT cycle (classic behaviour) and
// the PC update mux lets the redirect win over +4.
void CPU6V::if_step(uint32_t fetch_pc, bool stalled) {
    if (stalled || stream_end) return;                 // hold if_id / program drained
    uint32_t w = mem.read_word(fetch_pc);
    if (w == 0 && fetch_pc > 0 && !flush_pending) {
        stream_end = true;                             // stop fetching; drain pipeline
        return;
    }
    if_id = PipePkt{};
    if_id.inst_word  = w;
    if_id.pc         = fetch_pc;
    if_id.valid      = true;
    if_id.upc        = V_ENTRY_FETCH;                  // µPC at the shared routine head
    if_id.fetch_cycle= cycle;
    if (!flush_pending) rf.pc = fetch_pc + 4;          // PC mux: redirect wins over +4
}

// =====================================================================
// Clock edge orchestrator: WB -> MA -> EX -> OF -> ID -> IF, then flush.
// The late-to-early order is what makes same-cycle bypassing possible:
// a value produced this cycle (EX / MA) is visible to this cycle's OF read.
// =====================================================================

RiscException CPU6V::step_cycle() {
    if (halted) return { ExKind::Halt, rf.pc, "halted" };
    RiscException ex{};

    // Drain-complete check: stream over and nothing left in flight.
    if (stream_end && !if_id.valid && !id_of.valid && !of_ex.valid
                   && !ex_ma.valid && !ma_wb.valid) {
        halted = true;
        return { ExKind::Halt, rf.pc, "End of program (zero word)" };
    }

    uint32_t fetch_pc = rf.pc;          // IF's address latch for this cycle

    // 0. Apply pending flush from last cycle's EX redirect (squash younger).
    if (flush_pending) {
        flushed_insts += (if_id.valid ? 1 : 0) + (id_of.valid ? 1 : 0) + (of_ex.valid ? 1 : 0);
        if_id = PipePkt{}; id_of = PipePkt{}; of_ex = PipePkt{};
        flush_pending = false;
    }

    // Load-use interlock check (after flush: squashed consumers don't stall).
    bool stalled = detect_of_stall();
    if (stalled) load_stall_cycles++;

    // 1. WB
    wb_step(ex);
    if (ex.kind == ExKind::StackOverflow) {
        // Precise squash of everything younger than the faulting packet.
        flushed_insts += (ex_ma.valid ? 1 : 0) + (of_ex.valid ? 1 : 0)
                       + (id_of.valid ? 1 : 0) + (if_id.valid ? 1 : 0);
        ex_ma = PipePkt{}; of_ex = PipePkt{}; id_of = PipePkt{}; if_id = PipePkt{};
        halted = true;
        return ex;
    }

    // 2. MA
    ma_step();

    // 3. EX
    ex_step(ex);
    if (ex.kind != ExKind::None) return ex;             // DivByZero (already halted)

    // 4. OF   5. ID   6. IF
    of_step(stalled);
    id_step(stalled);
    if_step(fetch_pc, stalled);

    count_in_flight();
    cycle++;
    return ex;
}

void CPU6V::count_in_flight() {
    uint64_t n = (if_id.valid ? 1 : 0) + (id_of.valid ? 1 : 0) + (of_ex.valid ? 1 : 0)
               + (ex_ma.valid ? 1 : 0) + (ma_wb.valid ? 1 : 0);
    if (n > max_in_flight) max_in_flight = n;
}

RiscException CPU6V::step_micro() { return step_cycle(); }

RiscException CPU6V::step() {
    if (halted) return { ExKind::Halt, rf.pc, "halted" };
    uint64_t start_retired = inst_retired;
    RiscException ex{};
    while (inst_retired == start_retired && !halted) {
        ex = step_cycle();
        if (ex.kind != ExKind::None) return ex;
    }
    return ex;
}

uint8_t CPU6V::current_upc() const {
    if (ma_wb.valid)  return ma_wb.upc;
    if (ex_ma.valid)  return ex_ma.upc;
    if (of_ex.valid)  return of_ex.upc;
    if (id_of.valid)  return id_of.upc;
    if (if_id.valid)  return if_id.upc;
    return 0;
}

// =====================================================================
// Snapshots
// =====================================================================

static std::string pkt_stage_text(const PipePkt& p) {
    if (!p.valid) return std::string("(bubble)");
    char buf[160];
    std::string mnem = opcode_mnemonic(p.op);
    std::snprintf(buf, sizeof(buf), "pc=0x%04x %-5s µPC=%-3d",
                  p.pc, mnem.c_str(), (int)p.upc);
    return std::string(buf);
}

std::string CPU6V::pipeline_snapshot() const {
    std::ostringstream os;
    os << "Pipeline (6-stage, OPERATIONAL, vertical µcode)  cycle=" << cycle
       << "  retired=" << inst_retired << "\n";
    auto ifline = [&]() {
        if (!if_id.valid) return std::string("(idle)");
        char b[96];
        std::snprintf(b, sizeof(b), "pc=0x%04x word=0x%08x µPC=%d",
                      if_id.pc, if_id.inst_word, (int)if_id.upc);
        return std::string(b);
    };
    os << "  IF : " << ifline() << "\n";
    os << "  ID : " << pkt_stage_text(id_of) << "\n";
    os << "  OF : " << pkt_stage_text(of_ex) << "\n";
    os << "  EX : " << pkt_stage_text(ex_ma) << "\n";
    os << "  MA : " << pkt_stage_text(ma_wb) << "\n";
    os << "  WB : " << pkt_stage_text(wb_retire) << "\n";
    char mline[160];
    std::snprintf(mline, sizeof(mline),
        "  MAR=0x%06x  MDR=0x%08x  ALU=0x%08x  flags: E=%d GT=%d\n",
        mar, mdr, alu_out.value, (int)rf.flags.E, (int)rf.flags.GT);
    os << mline;
    os << "  in-flight=" << ((if_id.valid?1:0)+(id_of.valid?1:0)+(of_ex.valid?1:0)
                              +(ex_ma.valid?1:0)+(ma_wb.valid?1:0))
       << " (max " << max_in_flight << ")"
       << "  redirects=" << redirect_count
       << "  flushed=" << flushed_insts
       << "  bypasses=" << bypass_hits << "\n";
    return os.str();
}

std::string CPU6V::regfile_snapshot() const {
    std::ostringstream os;
    os << "---- Registers / Flags / PC ----\n";
    for (int i = 0; i < REG_COUNT; ++i) {
        char buf[64];
        std::snprintf(buf, sizeof(buf), "%4s=0x%08x  ",
                      register_name(i).c_str(), rf.r[i]);
        os << buf;
        if ((i & 3) == 3) os << "\n";
    }
    char pc[64];
    std::snprintf(pc, sizeof(pc), "PC  =0x%08x\n", rf.pc);
    os << pc;
    os << "flags: E=" << (int)rf.flags.E << " GT=" << (int)rf.flags.GT
       << "  µPC=" << (int)current_upc() << "\n";
    return os.str();
}

std::string CPU6V::micro_snapshot() const {
    std::ostringstream os;
    os << "Microcode sequencers (vertical, one µPC per in-flight packet):\n";
    auto line = [&](const char* stage, const PipePkt& p) {
        if (!p.valid) {
            char b[96]; std::snprintf(b, sizeof(b), "  %-5s (no packet)\n", stage);
            os << b; return;
        }
        const VMicroOp& m = vuc.rom[p.upc];
        char b[176];
        std::snprintf(b, sizeof(b),
            "  %-5s pc=0x%04x µPC=%-3d µword: %s (arg1=%d arg2=%d cond=%d)\n",
            stage, p.pc, (int)p.upc, vaction_name((VAction)m.action),
            (int)m.arg1, (int)m.arg2, (int)m.cond);
        os << b;
    };
    line("IF/ID", if_id);
    line("ID/OF", id_of);
    line("OF/EX", of_ex);
    line("EX/MA", ex_ma);
    line("MA/WB", ma_wb);
    os << "  ROM: " << VROM_SIZE << " µwords, 32-bit vertical (1 action/µop)"
       << "; dispatch[opcode] -> 16 + opcode*4\n";
    return os.str();
}

} // namespace risc201
