// risc201/src/main.cpp — CLI entry.
//
// Usage:
//   risc201-6stage <program.s> [mode]
//   modes: --trace, --debug, --listing, --disasm, --hex
//
// The CPU uses a vertical microcode control unit (32-bit µword,
// 1 action per µop, ~5 µops/macro).

#include "risc201/cpu6.hpp"
#include "risc201/assembler.hpp"
#include "risc201/debugger.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>

using namespace risc201;

static void usage(const char* prog) {
    std::cerr <<
        "Risc201 6-stage CPU (vertical microcode)\n"
        "Usage: " << prog << " <program.s> [mode]\n"
        "  Modes:\n"
        "    (default)  run to halt, print final regs\n"
        "    --trace    log every cycle to stdout\n"
        "    --debug    interactive debugger REPL\n"
        "    --listing  print assembler listing\n"
        "    --disasm   disassemble program\n"
        "    --hex      print program as hex words\n";
}

int main(int argc, char** argv) {
    if (argc < 2) { usage(argv[0]); return 1; }
    std::string file = argv[1];
    std::string mode;
    for (int i = 2; i < argc; ++i) mode = argv[i];

    std::ifstream in(file);
    if (!in) { std::cerr << "cannot open " << file << "\n"; return 1; }
    std::ostringstream ss; ss << in.rdbuf();
    std::string src = ss.str();

    auto result = assemble(src);
    if (!result.ok) {
        std::cerr << "Assemble errors:\n";
        for (auto& e : result.errors) std::cerr << "  " << e << "\n";
        return 1;
    }

    if (mode == "--listing") {
        for (auto& l : result.listing) std::cout << l << "\n";
        return 0;
    }
    if (mode == "--disasm") {
        std::cout << disassemble_program(result.words);
        return 0;
    }
    if (mode == "--hex") {
        for (size_t i = 0; i < result.words.size(); ++i) {
            std::cout << std::hex << std::setw(8) << std::setfill('0')
                      << result.words[i] << (i % 8 == 7 ? "\n" : " ");
        }
        std::cout << "\n";
        return 0;
    }

    Debug6V dbg(result.words);
    if (mode == "--debug") { interactive_repl(dbg, std::cin, std::cout); return 0; }
    if (mode == "--trace") { trace_run(dbg, std::cout, 100000); return 0; }
    RiscException ex;
    uint64_t max_cycles = 1000000;
    while (!dbg.is_halted() && max_cycles-- > 0) {
        ex = dbg.step_one_macro();
        if (ex.kind != ExKind::None && ex.kind != ExKind::Halt) {
            std::cout << "runtime exception: " << exkind_name(ex.kind)
                      << " at pc=0x" << std::hex << ex.pc << std::dec
                      << " — " << ex.message << "\n";
            break;
        }
    }
    std::cout << dbg.regfile_snapshot();
    double cpi = dbg.retired_count()
               ? (double)dbg.cycle_count() / (double)dbg.retired_count() : 0.0;
    std::cout << "  cycles=" << std::dec << dbg.cycle_count()
              << "  retired=" << dbg.retired_count()
              << "  CPI=" << std::fixed << std::setprecision(2) << cpi
              << "  clock=" << (dbg.cycle_period_ps() / 1000.0) << "ns/cyc"
              << "  time=" << (dbg.elapsed_time_ps() / 1000.0) << "ns"
              << "  redirects=" << dbg.redirect_count()
              << "  flushed=" << dbg.flushed_count()
              << "  max-in-flight=" << dbg.max_in_flight() << "\n";
    return 0;
}
